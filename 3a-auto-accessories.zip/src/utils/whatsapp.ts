export const STORE_CONTACT = {
  name: 'Ankit Kumar',
  brandName: '3A Auto Accessories',
  phone: '+919958473159', // Direct WhatsApp / Phone number
  displayPhone: '+91 99584 73159',
  email: 'cqmsankitkumar2473@gmail.com',
  address: 'Chabi Ganj, Kashmere Gate, Old Delhi',
  cityState: 'New Delhi, Delhi - 110006, India',
  fullAddress: 'Chabi Ganj, Kashmere Gate, Old Delhi, New Delhi, Delhi 110006, India',
  workingHours: 'Mon - Sun: 10:00 AM - 9:00 PM',
  googleMapsUrl: 'https://maps.google.com/?q=Chabi+Ganj,+Kashmere+Gate,+Old+Delhi,+New+Delhi,+Delhi+110006,+India',
  embedMapUrl: 'https://maps.google.com/maps?q=Chabi%20Ganj,%20Kashmere%20Gate,%20Old%20Delhi,%20New%20Delhi,%20Delhi%20110006,%20India&t=&z=16&ie=UTF8&iwloc=&output=embed'
};

/**
 * Builds a clean, encoded WhatsApp click-to-chat URL
 */
export function buildWhatsAppUrl(message: string, customPhone?: string): string {
  const phone = (customPhone || STORE_CONTACT.phone).replace(/\D/g, '');
  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}

/**
 * Generates an inquiry message for a specific product
 */
export function getProductInquiryMessage(productName: string, price: number, carModel: string = ''): string {
  const carText = carModel.trim() ? ` for my car: ${carModel.trim()}` : '';
  return `Hello Ankit Kumar Sir,\n\nI am visiting the *3A Auto Accessories* website and I am interested in:\n📦 *Product:* ${productName}\n💰 *Price:* ₹${price.toLocaleString('en-IN')}${carText}\n\nCould you please confirm availability, exact car fitment, and installation timing?\n\nThank you!`;
}

/**
 * Generates a message for custom modification package
 */
export function getPackageInquiryMessage(packageName: string, price: number, carModel: string = ''): string {
  const carText = carModel.trim() ? ` for my vehicle: ${carModel.trim()}` : '';
  return `Hello Ankit Kumar Sir,\n\nI want to book / inquire about the modification package:\n🔥 *Package:* ${packageName}\n💰 *Offer Price:* ₹${price.toLocaleString('en-IN')}${carText}\n\nPlease share available installation slots and complete details.\n\nThank you!`;
}

/**
 * Generates an inquiry message for multi-item cart/basket
 */
export function getMultiItemInquiryMessage(items: { name: string; price: number; quantity: number; carModel?: string }[]): string {
  const itemsList = items
    .map((item, index) => `${index + 1}. ${item.name} (Qty: ${item.quantity}) - ₹${(item.price * item.quantity).toLocaleString('en-IN')}${item.carModel ? ` [For: ${item.carModel}]` : ''}`)
    .join('\n');

  const total = items.reduce((acc, curr) => acc + curr.price * curr.quantity, 0);

  return `Hello Ankit Kumar Sir,\n\nI have created a custom accessories wishlist on *3A Auto Accessories*:\n\n${itemsList}\n\n💳 *Estimated Total:* ₹${total.toLocaleString('en-IN')}\n\nPlease let me know the best combo discount and installation schedule.\n\nThank you!`;
}

/**
 * General store inquiry message
 */
export function getGeneralInquiryMessage(): string {
  return `Hello Ankit Kumar Sir,\n\nI visited *3A Auto Accessories* online and would like to inquire about car accessories and custom modification options for my vehicle.\n\nPlease guide me on the latest products and prices.\n\nThank you!`;
}
