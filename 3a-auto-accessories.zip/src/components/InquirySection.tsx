import React, { useState } from 'react';
import { 
  Send, 
  MessageSquare, 
  Car, 
  CheckCircle2, 
  Phone, 
  Calendar, 
  Sparkles,
  HelpCircle,
  Clock
} from 'lucide-react';
import { InquiryItem } from '../types';
import { STORE_CONTACT, buildWhatsAppUrl } from '../utils/whatsapp';
import confetti from 'canvas-confetti';

interface InquirySectionProps {
  onSaveInquiry: (inquiry: InquiryItem) => void;
}

export const InquirySection: React.FC<InquirySectionProps> = ({ onSaveInquiry }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [carModel, setCarModel] = useState('');
  const [category, setCategory] = useState('LED Headlights & Fog Lamps');
  const [message, setMessage] = useState('');
  const [preferredDate, setPreferredDate] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) return;

    const newInquiry: InquiryItem = {
      id: `inq-${Date.now()}`,
      customerName: name.trim(),
      phoneNumber: phone.trim(),
      email: email.trim(),
      carModel: carModel.trim() || 'Not specified',
      selectedCategory: category,
      message: message.trim(),
      preferredDate: preferredDate || 'Flexible',
      status: 'new',
      createdAt: new Date().toLocaleDateString('en-IN')
    };

    onSaveInquiry(newInquiry);
    setSubmitted(true);

    try {
      confetti({
        particleCount: 70,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch (_) {}

    // Generate WhatsApp direct bridge
    const waText = `Hello Ankit Kumar Sir,\n\nI just submitted an inquiry on *3A Auto Accessories*:\n👤 *Name:* ${name.trim()}\n📞 *Phone:* ${phone.trim()}\n🚘 *Vehicle:* ${carModel.trim() || 'Custom'}\n🔧 *Requirement:* ${category}\n📅 *Preferred Fitment Date:* ${preferredDate || 'Flexible'}\n💬 *Details:* ${message.trim() || 'Please share product recommendations & prices.'}\n\nPlease confirm availability.\n\nThank you!`;
    
    setTimeout(() => {
      const url = buildWhatsAppUrl(waText);
      window.open(url, '_blank', 'noopener,noreferrer');
    }, 1200);
  };

  const handleReset = () => {
    setSubmitted(false);
    setName('');
    setPhone('');
    setEmail('');
    setCarModel('');
    setMessage('');
    setPreferredDate('');
  };

  return (
    <section id="inquiry-section" className="py-16 sm:py-24 bg-white/60 backdrop-blur-md border-b border-slate-200/60 relative">
      {/* Background glow */}
      <div className="absolute top-1/2 left-10 w-96 h-96 bg-amber-100/25 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="bg-gradient-to-br from-[#001F3F]/95 via-[#0A3663]/90 to-[#001730]/95 backdrop-blur-2xl rounded-3xl overflow-hidden shadow-2xl border border-[#D4AF37]/40 relative">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#D4AF37]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 p-6 sm:p-10 lg:p-12 items-center relative z-10">
            
            {/* Left Column: Value Proposition & Contact Quick Links */}
            <div className="lg:col-span-5 text-white space-y-6">
              <div className="inline-flex items-center space-x-2 bg-white/10 border border-[#D4AF37]/50 text-[#D4AF37] rounded-full px-3.5 py-1 text-xs font-semibold uppercase tracking-wider backdrop-blur-md shadow-xs">
                <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Expert Fitment & Pricing Consultation</span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-bold font-serif text-white tracking-tight leading-tight">
                Request a Custom Quote or Installation Slot
              </h2>

              <p className="text-slate-200 text-sm leading-relaxed">
                Not sure which LED projector lens, Android system, or seat cover best suits your car? Fill out the form or WhatsApp Ankit Kumar directly for personalized recommendations and combo discounts.
              </p>

              {/* Consultation Perks */}
              <div className="space-y-3 pt-2 text-xs sm:text-sm text-slate-200">
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center shrink-0 border border-[#D4AF37]/40">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <span>100% Free Car Fitment Consultation</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center shrink-0 border border-[#D4AF37]/40">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <span>Zero Wire-Cut Plug & Play Guarantee</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center shrink-0 border border-[#D4AF37]/40">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <span>Priority Workshop Bay Reservation</span>
                </div>
              </div>

              {/* Direct Store Helpline */}
              <div className="pt-4 border-t border-white/15 flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-300">Direct Helpline:</p>
                  <p className="text-lg font-bold text-[#D4AF37]">{STORE_CONTACT.displayPhone}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-slate-300">Owner & Specialist:</p>
                  <p className="text-sm font-bold text-white">Ankit Kumar</p>
                </div>
              </div>
            </div>

            {/* Right Column: Inquiry Form (Frosted Glass Card) */}
            <div className="lg:col-span-7">
              <div className="bg-white/95 backdrop-blur-2xl rounded-3xl p-6 sm:p-8 shadow-2xl text-slate-900 border border-white/90">
                {submitted ? (
                  <div className="py-10 text-center space-y-4">
                    <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
                      <CheckCircle2 className="w-8 h-8 text-emerald-600 animate-pulse" />
                    </div>
                    <h3 className="text-2xl font-bold font-serif text-[#001F3F]">
                      Inquiry Received Successfully!
                    </h3>
                    <p className="text-slate-600 text-xs sm:text-sm max-w-md mx-auto">
                      Thank you <span className="font-bold text-slate-900">{name}</span>. Ankit Kumar will review your requirements for <span className="font-bold text-slate-900">{carModel || 'your car'}</span> and connect with you shortly.
                    </p>
                    <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                      <a
                        href={buildWhatsAppUrl(`Hi Ankit Kumar, I just submitted an inquiry for ${carModel}.`)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-6 py-3 rounded-xl text-xs shadow-md border border-emerald-400/40"
                      >
                        <MessageSquare className="w-4 h-4" />
                        <span>Chat on WhatsApp Now</span>
                      </a>
                      <button
                        onClick={handleReset}
                        className="w-full sm:w-auto px-5 py-3 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-50"
                      >
                        Submit Another Inquiry
                      </button>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <h3 className="text-xl font-bold font-serif text-[#001F3F] mb-4">
                      Book Installation / Get Quotation
                    </h3>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          Full Name *
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Rahul Sharma"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className="w-full text-xs px-3.5 py-2.5 bg-slate-50/80 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-[#D4AF37] focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          WhatsApp / Mobile Number *
                        </label>
                        <input
                          type="tel"
                          required
                          placeholder="e.g. 9876543210"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          className="w-full text-xs px-3.5 py-2.5 bg-slate-50/80 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-[#D4AF37] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          Car Make, Model & Year *
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Mahindra Thar 4x4 / Creta 2024"
                          value={carModel}
                          onChange={(e) => setCarModel(e.target.value)}
                          className="w-full text-xs px-3.5 py-2.5 bg-slate-50/80 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-[#D4AF37] focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          Category of Interest
                        </label>
                        <select
                          value={category}
                          onChange={(e) => setCategory(e.target.value)}
                          className="w-full text-xs px-3.5 py-2.5 bg-slate-50/80 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-[#D4AF37] focus:outline-none cursor-pointer"
                        >
                          <option value="LED Headlights & Fog Lamps">LED Headlights & Fog Lamps</option>
                          <option value="Temple Flags & Dashboard Idols">Temple Flags & Dashboard Idols</option>
                          <option value="Interior Symphony Ambient Lighting">Interior Symphony Ambient Lighting</option>
                          <option value="Android Screen & Wireless CarPlay">Android Screen & Wireless CarPlay</option>
                          <option value="Custom Seat Covers & 7D Mats">Custom Seat Covers & 7D Mats</option>
                          <option value="Valvetronic Exhaust & Modifications">Valvetronic Exhaust & Modifications</option>
                          <option value="9H Ceramic Coating & Car Detailing">9H Ceramic Coating & Car Detailing</option>
                          <option value="Complete All-Round Transformation Combo">Complete All-Round Transformation Combo</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          Email Address (Optional)
                        </label>
                        <input
                          type="email"
                          placeholder="e.g. name@example.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full text-xs px-3.5 py-2.5 bg-slate-50/80 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-[#D4AF37] focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          Preferred Fitment Date
                        </label>
                        <input
                          type="date"
                          value={preferredDate}
                          onChange={(e) => setPreferredDate(e.target.value)}
                          className="w-full text-xs px-3.5 py-2.5 bg-slate-50/80 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-[#D4AF37] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Specific Requirements / Questions
                      </label>
                      <textarea
                        rows={2}
                        placeholder="Tell us what you'd like installed or ask about compatibility..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        className="w-full text-xs p-3 bg-slate-50/80 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-[#D4AF37] focus:outline-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-[#001F3F] hover:bg-[#0A3663] text-[#D4AF37] font-bold py-3.5 px-4 rounded-xl text-xs flex items-center justify-center space-x-2 shadow-lg transition-all border border-[#D4AF37]/40"
                    >
                      <Send className="w-4 h-4 text-[#D4AF37]" />
                      <span>Submit Inquiry & Connect with Ankit Kumar</span>
                    </button>
                  </form>
                )}
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
