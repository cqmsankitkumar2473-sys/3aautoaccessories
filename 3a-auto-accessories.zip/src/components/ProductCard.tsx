import React from 'react';
import { 
  Star, 
  MessageSquare, 
  Eye, 
  ShoppingBag, 
  Check, 
  Sparkles, 
  ShieldCheck, 
  Clock 
} from 'lucide-react';
import { Product } from '../types';
import { buildWhatsAppUrl, getProductInquiryMessage } from '../utils/whatsapp';

interface ProductCardProps {
  product: Product;
  onOpenModal: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  isInCart: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onOpenModal,
  onAddToCart,
  isInCart,
}) => {
  const discountPercent = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );

  const handleWhatsAppClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const url = buildWhatsAppUrl(
      getProductInquiryMessage(product.name, product.price)
    );
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleCartClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product);
  };

  return (
    <div
      id={`product-card-${product.id}`}
      onClick={() => onOpenModal(product)}
      className="group bg-white/75 hover:bg-white/95 backdrop-blur-md rounded-2xl border border-white/80 hover:border-[#D4AF37]/70 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden cursor-pointer relative"
    >
      {/* Product Image Stage */}
      <div className="relative aspect-4/3 bg-slate-900 overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
          loading="lazy"
        />

        {/* Gradient Shadow Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-black/30 pointer-events-none" />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
          {product.badge && (
            <span className="bg-[#D4AF37] text-[#001F3F] font-bold text-[11px] px-2.5 py-0.5 rounded-md shadow-md flex items-center">
              <Sparkles className="w-3 h-3 mr-1" />
              {product.badge}
            </span>
          )}
          {discountPercent > 0 && (
            <span className="bg-rose-600 text-white font-bold text-[11px] px-2 py-0.5 rounded-md shadow-md">
              {discountPercent}% OFF
            </span>
          )}
        </div>

        {/* Top Right: Stock Status */}
        <div className="absolute top-3 right-3 z-10">
          {product.inStock ? (
            <span className="bg-emerald-950/80 text-emerald-400 border border-emerald-500/40 text-[10px] font-semibold px-2 py-0.5 rounded-full backdrop-blur-md">
              In Stock
            </span>
          ) : (
            <span className="bg-slate-900/80 text-rose-400 border border-rose-500/40 text-[10px] font-semibold px-2 py-0.5 rounded-full backdrop-blur-md">
              Pre-Order
            </span>
          )}
        </div>

        {/* Quick View Button Hover Overlay */}
        <div className="absolute inset-0 bg-slate-950/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 pointer-events-none">
          <button 
            type="button"
            className="bg-white/90 hover:bg-white text-[#001F3F] font-bold text-xs px-3.5 py-2 rounded-xl shadow-lg backdrop-blur-md flex items-center space-x-1.5 pointer-events-auto transform translate-y-2 group-hover:translate-y-0 transition-all duration-300 border border-white/60"
          >
            <Eye className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Quick Specs & Gallery</span>
          </button>
        </div>

        {/* Category Pill Tag */}
        <div className="absolute bottom-2.5 left-3">
          <span className="text-[11px] font-medium text-slate-100 bg-black/60 backdrop-blur-md px-2 py-0.5 rounded border border-white/10">
            {product.categoryName}
          </span>
        </div>
      </div>

      {/* Product Content Body */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        
        {/* Rating & Warranty Tag */}
        <div>
          <div className="flex items-center justify-between text-xs mb-2">
            <div className="flex items-center space-x-1">
              <div className="flex text-[#D4AF37]">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-3.5 h-3.5 ${
                      i < Math.floor(product.rating)
                        ? 'fill-[#D4AF37] text-[#D4AF37]'
                        : 'text-slate-300'
                    }`}
                  />
                ))}
              </div>
              <span className="font-bold text-slate-800 text-xs ml-1">
                {product.rating}
              </span>
              <span className="text-slate-400 text-[11px]">
                ({product.reviewsCount})
              </span>
            </div>

            <div className="flex items-center text-slate-500 text-[11px]">
              <ShieldCheck className="w-3 h-3 text-emerald-600 mr-0.5" />
              <span>{product.warranty.split(' ')[0]} {product.warranty.split(' ')[1]}</span>
            </div>
          </div>

          {/* Product Title */}
          <h3 className="font-bold text-[#001F3F] text-sm sm:text-base line-clamp-2 leading-snug group-hover:text-[#D4AF37] transition-colors">
            {product.name}
          </h3>

          {/* Short description */}
          <p className="text-xs text-slate-500 mt-1.5 line-clamp-2 leading-relaxed">
            {product.shortDesc}
          </p>

          {/* Quick Fitment / Time snippet */}
          <div className="mt-2.5 flex items-center space-x-3 text-[11px] text-slate-500">
            <span className="flex items-center">
              <Clock className="w-3 h-3 mr-1 text-slate-400" />
              {product.installationTime}
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-emerald-700 font-medium truncate max-w-[140px]">
              {product.compatibleCars[0]}
            </span>
          </div>
        </div>

        {/* Price & Action Buttons */}
        <div className="mt-4 pt-3 border-t border-slate-100">
          <div className="flex items-baseline justify-between mb-3">
            <div>
              <span className="text-xs text-slate-400 mr-1">MRP:</span>
              <span className="text-base sm:text-lg font-extrabold text-[#001F3F]">
                ₹{product.price.toLocaleString('en-IN')}
              </span>
              <span className="text-xs text-slate-400 line-through ml-1.5">
                ₹{product.originalPrice.toLocaleString('en-IN')}
              </span>
            </div>
            <span className="text-[11px] text-emerald-700 font-bold bg-emerald-50/90 border border-emerald-200/60 px-1.5 py-0.5 rounded">
              Save ₹{(product.originalPrice - product.price).toLocaleString('en-IN')}
            </span>
          </div>

          <div className="grid grid-cols-5 gap-2">
            {/* WhatsApp Direct Inquiry Button (4 cols) */}
            <button
              id={`whatsapp-inquire-btn-${product.id}`}
              onClick={handleWhatsAppClick}
              className="col-span-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold text-xs py-2.5 px-3 rounded-xl flex items-center justify-center space-x-1.5 shadow-xs transition-colors duration-200"
              title="Inquire availability on WhatsApp"
            >
              <MessageSquare className="w-4 h-4 text-white" />
              <span>WhatsApp Inquiry</span>
            </button>

            {/* Add to Quotation Basket Button (1 col) */}
            <button
              id={`cart-add-btn-${product.id}`}
              onClick={handleCartClick}
              className={`col-span-1 border rounded-xl flex items-center justify-center transition-colors duration-200 ${
                isInCart 
                  ? 'bg-[#D4AF37] border-[#D4AF37] text-[#001F3F]' 
                  : 'border-slate-200/80 text-slate-700 hover:bg-white hover:text-slate-900 bg-white/60'
              }`}
              title={isInCart ? 'Item in wishlist basket' : 'Add to quotation wishlist'}
              aria-label="Add to wishlist"
            >
              {isInCart ? <Check className="w-4 h-4 font-bold" /> : <ShoppingBag className="w-4 h-4" />}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
