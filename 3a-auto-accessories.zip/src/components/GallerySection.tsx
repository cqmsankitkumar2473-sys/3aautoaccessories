import React, { useState } from 'react';
import { 
  Camera, 
  Sparkles, 
  Eye, 
  X, 
  MessageSquare, 
  Car,
  ZoomIn
} from 'lucide-react';
import { GALLERY_PROJECTS, GalleryItem } from '../data/gallery';
import { buildWhatsAppUrl } from '../utils/whatsapp';

export const GallerySection: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [activeModalItem, setActiveModalItem] = useState<GalleryItem | null>(null);

  const filteredItems = activeFilter === 'all' 
    ? GALLERY_PROJECTS 
    : GALLERY_PROJECTS.filter(item => item.category === activeFilter);

  const handleInquireProject = (item: GalleryItem) => {
    const msg = `Hello Ankit Kumar Sir,\n\nI saw the transformation photo of *${item.title}* on your website for *${item.carModel}*.\n\nI would like to get a similar modification done for my car. Could you please share the estimate and time required?\n\nThank you!`;
    const url = buildWhatsAppUrl(msg);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="gallery-section" className="py-16 sm:py-24 bg-white/60 backdrop-blur-md border-b border-slate-200/60 relative">
      {/* Background glow */}
      <div className="absolute top-10 left-10 w-96 h-96 bg-amber-100/20 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <div className="inline-flex items-center space-x-2 bg-white/80 border border-[#D4AF37]/50 text-[#001F3F] rounded-full px-3.5 py-1 text-xs font-semibold uppercase tracking-wider mb-2 backdrop-blur-md shadow-xs">
              <Camera className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Real Customer Builds</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold font-serif text-[#001F3F] tracking-tight">
              Customer Car Transformations
            </h2>
            <p className="text-slate-600 text-sm sm:text-base mt-2 max-w-2xl">
              Inspect our high-precision fitments: Bi-LED projector retrofits, concealed fiber ambient lighting, custom Nappa seats, and off-road styling.
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="mt-4 md:mt-0 flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
            {['all', 'lighting', 'interior', 'modification', 'flags'].map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveFilter(cat)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-semibold capitalize transition-all backdrop-blur-md ${
                  activeFilter === cat
                    ? 'bg-[#001F3F] text-[#D4AF37] shadow-sm border border-[#D4AF37]/50'
                    : 'bg-white/80 text-slate-700 hover:bg-white hover:text-slate-900 border border-slate-200/60'
                }`}
              >
                {cat === 'all' ? 'All Builds' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              onClick={() => setActiveModalItem(item)}
              className="group bg-slate-900 rounded-3xl overflow-hidden border border-white/70 hover:border-[#D4AF37]/70 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer relative flex flex-col backdrop-blur-md"
            >
              {/* Image Container */}
              <div className="relative aspect-16/10 overflow-hidden bg-slate-950">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
                  loading="lazy"
                />

                {/* Dark Gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-black/20 to-transparent" />

                {/* Top Badge (Frosted Glass) */}
                <div className="absolute top-3 left-3">
                  <span className="bg-black/60 backdrop-blur-md border border-[#D4AF37]/50 text-[#D4AF37] font-bold text-[11px] px-2.5 py-1 rounded-lg flex items-center shadow-md">
                    <Car className="w-3 h-3 mr-1" />
                    {item.carModel}
                  </span>
                </div>

                {/* Zoom Icon Overlay */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                  <div className="w-11 h-11 rounded-full bg-white/90 backdrop-blur-md flex items-center justify-center text-[#001F3F] shadow-lg transform scale-90 group-hover:scale-100 transition-transform">
                    <ZoomIn className="w-5 h-5 text-[#D4AF37]" />
                  </div>
                </div>

                {/* Bottom Overlay Title on Image */}
                <div className="absolute bottom-3 left-3 right-3">
                  <h3 className="text-white font-bold text-sm line-clamp-1">
                    {item.title}
                  </h3>
                  <p className="text-slate-300 text-xs mt-0.5 line-clamp-1">
                    {item.description}
                  </p>
                </div>
              </div>

              {/* Bottom Quick Bar (Frosted Glass) */}
              <div className="p-3.5 bg-white/80 backdrop-blur-md border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-700 capitalize">
                  {item.category} Upgrade
                </span>
                <span className="text-[#001F3F] font-bold flex items-center group-hover:text-[#D4AF37] transition-colors">
                  View HD Lightbox &rarr;
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Lightbox / Zoom Modal (Frosted Glass Backdrop) */}
        {activeModalItem && (
          <div
            className="fixed inset-0 z-50 bg-[#00142A]/85 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6"
            onClick={() => setActiveModalItem(null)}
          >
            <div
              className="relative max-w-4xl w-full bg-[#001F3F]/90 backdrop-blur-2xl rounded-3xl overflow-hidden border border-[#D4AF37]/50 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setActiveModalItem(null)}
                className="absolute top-4 right-4 z-10 bg-black/60 text-white p-2 rounded-full hover:bg-black transition-colors backdrop-blur-md"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="relative aspect-16/10 bg-black">
                <img
                  src={activeModalItem.image}
                  alt={activeModalItem.title}
                  className="w-full h-full object-contain"
                />
              </div>

              <div className="p-6 bg-[#001F3F]/95 backdrop-blur-xl text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-t border-white/10">
                <div>
                  <span className="text-xs font-bold text-[#D4AF37] uppercase tracking-wider">
                    {activeModalItem.carModel} • Verified Transformation
                  </span>
                  <h3 className="text-lg font-bold font-serif text-white mt-1">
                    {activeModalItem.title}
                  </h3>
                  <p className="text-xs text-slate-300 mt-1">
                    {activeModalItem.description}
                  </p>
                </div>

                <button
                  onClick={() => handleInquireProject(activeModalItem)}
                  className="shrink-0 inline-flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-3 rounded-xl text-xs transition-colors shadow-lg border border-emerald-400/40"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Inquire Similar Build</span>
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
