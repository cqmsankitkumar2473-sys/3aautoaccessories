import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  MessageSquare, 
  ShoppingBag, 
  Car, 
  ArrowRight, 
  ShieldCheck, 
  Plus, 
  Minus 
} from 'lucide-react';
import { CartItem } from '../types';
import { buildWhatsAppUrl, getMultiItemInquiryMessage } from '../utils/whatsapp';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  onExploreProducts: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onExploreProducts
}) => {
  const [globalCarModel, setGlobalCarModel] = useState('');

  if (!isOpen) return null;

  const totalAmount = cartItems.reduce(
    (acc, item) => acc + item.product.price * item.quantity,
    0
  );

  const totalOriginalAmount = cartItems.reduce(
    (acc, item) => acc + item.product.originalPrice * item.quantity,
    0
  );

  const savings = totalOriginalAmount - totalAmount;

  const handleSendWhatsAppQuote = () => {
    const itemsData = cartItems.map((ci) => ({
      name: ci.product.name,
      price: ci.product.price,
      quantity: ci.quantity,
      carModel: ci.carModel || globalCarModel || 'Vehicle model specified upon confirmation'
    }));

    const message = getMultiItemInquiryMessage(itemsData);
    const url = buildWhatsAppUrl(message);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div 
      className="fixed inset-0 z-50 overflow-hidden bg-[#001F3F]/60 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div 
          className="w-screen max-w-md bg-white/95 backdrop-blur-2xl shadow-2xl flex flex-col justify-between border-l border-white/80"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="p-5 bg-[#001F3F] text-white flex items-center justify-between border-b border-[#D4AF37]/30 shadow-sm">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center border border-[#D4AF37]/40">
                <ShoppingBag className="w-4 h-4 text-[#D4AF37]" />
              </div>
              <div>
                <h3 className="font-bold text-base font-serif">Wishlist & Quotation Basket</h3>
                <p className="text-[11px] text-slate-300">
                  {cartItems.length} {cartItems.length === 1 ? 'accessory' : 'accessories'} selected
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Content Body */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {cartItems.length === 0 ? (
              <div className="text-center py-16 space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-amber-50 text-[#D4AF37] flex items-center justify-center mx-auto border border-[#D4AF37]/40 shadow-xs">
                  <ShoppingBag className="w-7 h-7" />
                </div>
                <h4 className="font-bold text-[#001F3F] font-serif text-base">Your Wishlist is Empty</h4>
                <p className="text-xs text-slate-500 max-w-xs mx-auto">
                  Add LED headlights, temple flags, 7D mats, or ambient light kits to generate an instant combo discount quote.
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onExploreProducts();
                  }}
                  className="mt-3 px-5 py-2.5 bg-[#001F3F] hover:bg-[#0A3663] text-[#D4AF37] text-xs font-bold rounded-xl shadow-md border border-[#D4AF37]/40 transition-all"
                >
                  Browse Accessories
                </button>
              </div>
            ) : (
              <>
                {/* Vehicle model quick input */}
                <div className="p-3.5 bg-amber-50/80 rounded-2xl border border-[#D4AF37]/30 backdrop-blur-xs">
                  <label className="block text-xs font-bold text-[#001F3F] mb-1 flex items-center">
                    <Car className="w-3.5 h-3.5 mr-1 text-[#D4AF37]" />
                    Your Car Make & Model (For accurate fitment check):
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Mahindra Thar / Creta SX / Brezza"
                    value={globalCarModel}
                    onChange={(e) => setGlobalCarModel(e.target.value)}
                    className="w-full text-xs px-3 py-2 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] text-slate-900"
                  />
                </div>

                {/* Items List */}
                <div className="space-y-3 divide-y divide-slate-100">
                  {cartItems.map((item) => (
                    <div key={item.product.id} className="pt-3 first:pt-0 flex space-x-3 bg-white/70 p-3 rounded-2xl border border-slate-100 backdrop-blur-xs">
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-16 h-16 rounded-xl object-cover border border-slate-200 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <h5 className="text-xs font-bold text-[#001F3F] truncate">
                            {item.product.name}
                          </h5>
                          <button
                            onClick={() => onRemoveItem(item.product.id)}
                            className="text-slate-400 hover:text-rose-600 p-1"
                            title="Remove item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <p className="text-[11px] text-slate-500">
                          ₹{item.product.price.toLocaleString('en-IN')} each
                        </p>

                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center border border-slate-200 rounded-xl overflow-hidden bg-slate-50">
                            <button
                              onClick={() => onUpdateQuantity(item.product.id, -1)}
                              className="px-2 py-1 text-slate-600 hover:bg-slate-200 text-xs"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2.5 text-xs font-bold text-[#001F3F]">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => onUpdateQuantity(item.product.id, 1)}
                              className="px-2 py-1 text-slate-600 hover:bg-slate-200 text-xs"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <span className="text-xs font-bold text-[#001F3F]">
                            ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    onClick={onClearCart}
                    className="text-[11px] text-slate-400 hover:text-rose-600 underline"
                  >
                    Clear all items
                  </button>
                </div>
              </>
            )}
          </div>

          {/* Footer Summary & WhatsApp Button */}
          {cartItems.length > 0 && (
            <div className="p-5 bg-slate-50/90 backdrop-blur-md border-t border-slate-200 space-y-3">
              <div className="space-y-1.5 text-xs text-slate-600">
                <div className="flex justify-between">
                  <span>Total MRP:</span>
                  <span className="line-through">₹{totalOriginalAmount.toLocaleString('en-IN')}</span>
                </div>
                {savings > 0 && (
                  <div className="flex justify-between text-emerald-600 font-semibold">
                    <span>Instant Combo Savings:</span>
                    <span>-₹{savings.toLocaleString('en-IN')}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm font-extrabold text-[#001F3F] pt-2 border-t border-slate-200">
                  <span>Estimated Total:</span>
                  <span className="text-base text-[#D4AF37]">₹{totalAmount.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <button
                id="send-whatsapp-quotation-btn"
                onClick={handleSendWhatsAppQuote}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3.5 px-4 rounded-xl text-xs flex items-center justify-center space-x-2 shadow-lg shadow-emerald-700/20 transition-all border border-emerald-400/40"
              >
                <MessageSquare className="w-4 h-4 text-white" />
                <span>Send Multi-Item Quote to WhatsApp</span>
              </button>

              <p className="text-center text-[10px] text-slate-500">
                Ankit Kumar will review and share exclusive combo discounts & fitment slot.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
