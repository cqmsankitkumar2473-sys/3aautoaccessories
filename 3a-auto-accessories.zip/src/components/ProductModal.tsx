import React, { useState } from 'react';
import { 
  X, 
  Star, 
  MessageSquare, 
  ShieldCheck, 
  Clock, 
  Check, 
  ShoppingBag, 
  Car, 
  Sparkles, 
  Maximize2,
  PhoneCall,
  CheckCircle2,
  ZoomIn
} from 'lucide-react';
import { Product } from '../types';
import { STORE_CONTACT, buildWhatsAppUrl, getProductInquiryMessage } from '../utils/whatsapp';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, carModel?: string) => void;
  isInCart: boolean;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onAddToCart,
  isInCart,
}) => {
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [customerCarModel, setCustomerCarModel] = useState('');
  const [isZoomed, setIsZoomed] = useState(false);
  const [zoomPos, setZoomPos] = useState({ x: 50, y: 50 });

  if (!product) return null;

  const gallery = product.gallery && product.gallery.length > 0 ? product.gallery : [product.image];
  const activeImage = gallery[selectedImageIndex] || product.image;

  const discountPercent = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );

  const handleWhatsAppInquiry = () => {
    const message = getProductInquiryMessage(
      product.name,
      product.price,
      customerCarModel
    );
    const url = buildWhatsAppUrl(message);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isZoomed) return;
    const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;
    setZoomPos({ x, y });
  };

  return (
    <div 
      id="product-detail-modal-backdrop"
      className="fixed inset-0 z-50 overflow-y-auto bg-[#001F3F]/70 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 md:p-6 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="product-detail-modal-container"
        className="relative bg-white/95 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-4xl w-full max-h-[92vh] overflow-y-auto border border-white/90"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="close-product-modal-btn"
          onClick={onClose}
          className="absolute top-4 right-4 z-20 bg-[#001F3F]/80 hover:bg-[#001F3F] text-white p-2 rounded-full backdrop-blur-md transition-colors border border-white/20"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5 text-[#D4AF37]" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 p-5 sm:p-7 md:p-8">
          
          {/* Left Column: Interactive Image Gallery with Zoom */}
          <div className="md:col-span-6 space-y-4">
            
            {/* Main Active Image Stage */}
            <div
              className="relative aspect-4/3 rounded-3xl overflow-hidden bg-slate-900 border border-slate-200 cursor-crosshair group select-none shadow-md"
              onMouseEnter={() => setIsZoomed(true)}
              onMouseLeave={() => setIsZoomed(false)}
              onMouseMove={handleMouseMove}
            >
              <img
                src={activeImage}
                alt={product.name}
                className={`w-full h-full object-cover transition-transform duration-200 ${
                  isZoomed ? 'scale-200' : 'scale-100'
                }`}
                style={
                  isZoomed
                    ? {
                        transformOrigin: `${zoomPos.x}% ${zoomPos.y}%`,
                      }
                    : undefined
                }
              />

              {/* Badges */}
              <div className="absolute top-3 left-3 flex flex-wrap gap-2 pointer-events-none">
                {product.badge && (
                  <span className="bg-[#D4AF37] text-[#001F3F] font-bold text-xs px-2.5 py-1 rounded-md shadow">
                    {product.badge}
                  </span>
                )}
                <span className="bg-rose-600 text-white font-bold text-xs px-2.5 py-1 rounded-md shadow">
                  {discountPercent}% OFF
                </span>
              </div>

              {/* Hover Zoom Hint */}
              <div className="absolute bottom-3 right-3 bg-black/60 backdrop-blur-md text-white text-[11px] font-medium px-2.5 py-1 rounded-md pointer-events-none flex items-center space-x-1">
                <ZoomIn className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Hover to Zoom</span>
              </div>
            </div>

            {/* Thumbnail Carousel */}
            {gallery.length > 1 && (
              <div className="flex items-center space-x-3 overflow-x-auto pb-1">
                {gallery.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImageIndex(idx)}
                    className={`relative w-20 h-16 rounded-2xl overflow-hidden shrink-0 border-2 transition-all ${
                      selectedImageIndex === idx
                        ? 'border-[#D4AF37] shadow-md ring-2 ring-[#D4AF37]/30'
                        : 'border-slate-200 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={img}
                      alt={`${product.name} angle ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}

            {/* Guaranteed Trust Badges */}
            <div className="bg-slate-50/80 backdrop-blur-xs rounded-2xl p-4 border border-slate-200 space-y-2.5 text-xs text-slate-700">
              <div className="flex items-center space-x-2 font-semibold text-[#001F3F]">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>3A Authenticity & Fitment Guarantee</span>
              </div>
              <ul className="space-y-1.5 text-slate-600 pl-6 list-disc">
                <li>Zero wire cut installation protects your car manufacturer warranty.</li>
                <li>{product.warranty} direct replacement through Ankit Kumar.</li>
                <li>Professional fitting & alignment available at our store.</li>
              </ul>
            </div>
          </div>

          {/* Right Column: Title, Specs Table, Car Compatibility & CTAs */}
          <div className="md:col-span-6 flex flex-col justify-between space-y-5">
            <div>
              {/* Category & Status */}
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-[#001F3F] bg-amber-50 px-2.5 py-1 rounded-md border border-[#D4AF37]/40">
                  {product.categoryName}
                </span>
                <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200 flex items-center">
                  <CheckCircle2 className="w-3.5 h-3.5 mr-1 text-emerald-600" />
                  {product.inStock ? 'Ready for Fitment' : 'Available on Order'}
                </span>
              </div>

              {/* Product Title */}
              <h2 className="text-xl sm:text-2xl font-bold font-serif text-[#001F3F] mt-2">
                {product.name}
              </h2>

              {/* Rating & Reviews */}
              <div className="flex items-center space-x-2 mt-2">
                <div className="flex text-[#D4AF37]">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(product.rating)
                          ? 'fill-[#D4AF37] text-[#D4AF37]'
                          : 'text-slate-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm font-bold text-[#001F3F]">
                  {product.rating} / 5.0
                </span>
                <span className="text-xs text-slate-500">
                  ({product.reviewsCount} customer reviews)
                </span>
              </div>

              {/* Pricing Row (Frosted Glass Navy Gradient) */}
              <div className="mt-4 p-4 rounded-2xl bg-gradient-to-r from-[#001F3F] to-[#0A3663] text-white flex items-baseline justify-between shadow-lg border border-[#D4AF37]/30">
                <div>
                  <span className="text-xs text-slate-200 block">Offer Price (Incl. GST)</span>
                  <div className="flex items-baseline space-x-2 mt-0.5">
                    <span className="text-2xl sm:text-3xl font-extrabold text-[#D4AF37]">
                      ₹{product.price.toLocaleString('en-IN')}
                    </span>
                    <span className="text-sm text-slate-300 line-through">
                      ₹{product.originalPrice.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xs bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40 px-2.5 py-1 rounded-full font-bold">
                    You Save ₹{(product.originalPrice - product.price).toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {/* Description */}
              <p className="text-xs sm:text-sm text-slate-600 mt-4 leading-relaxed">
                {product.description}
              </p>

              {/* Technical Specifications Table */}
              <div className="mt-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#001F3F] mb-2">
                  Technical Specifications
                </h4>
                <div className="bg-slate-50/80 rounded-2xl border border-slate-200 overflow-hidden divide-y divide-slate-200 text-xs">
                  {Object.entries(product.specs).map(([key, value]) => (
                    <div key={key} className="grid grid-cols-12 px-3 py-2">
                      <span className="col-span-5 font-semibold text-slate-700">{key}</span>
                      <span className="col-span-7 text-slate-900 font-medium">{value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Vehicle Compatibility Input / Check */}
              <div className="mt-4 p-3.5 rounded-2xl bg-amber-50/70 border border-[#D4AF37]/30 backdrop-blur-xs">
                <label className="block text-xs font-bold text-[#001F3F] mb-1 flex items-center">
                  <Car className="w-3.5 h-3.5 mr-1 text-[#D4AF37]" />
                  Enter Your Car Make & Model for Fitment Check:
                </label>
                <input
                  type="text"
                  placeholder="e.g. Mahindra Thar 2024 / Hyundai Creta SX / Swift"
                  value={customerCarModel}
                  onChange={(e) => setCustomerCarModel(e.target.value)}
                  className="w-full text-xs px-3 py-2 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] text-slate-900 placeholder:text-slate-400"
                />
              </div>

            </div>

            {/* Bottom Actions */}
            <div className="space-y-2.5 pt-3 border-t border-slate-200">
              <button
                id="modal-whatsapp-enquiry-btn"
                onClick={handleWhatsAppInquiry}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3.5 px-4 rounded-xl flex items-center justify-center space-x-2 shadow-lg shadow-emerald-700/20 transition-all text-sm border border-emerald-400/40"
              >
                <MessageSquare className="w-5 h-5 text-white" />
                <span>Inquire on WhatsApp (Ankit Kumar)</span>
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  id="modal-add-to-cart-btn"
                  onClick={() => onAddToCart(product, customerCarModel)}
                  className={`py-3 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-1.5 border transition-all ${
                    isInCart
                      ? 'bg-[#D4AF37] border-[#D4AF37] text-[#001F3F]'
                      : 'bg-[#001F3F] text-[#D4AF37] border-[#001F3F] hover:bg-[#0A3663]'
                  }`}
                >
                  {isInCart ? <Check className="w-4 h-4" /> : <ShoppingBag className="w-4 h-4" />}
                  <span>{isInCart ? 'In Quote Wishlist' : 'Add to Wishlist'}</span>
                </button>

                <a
                  id="modal-call-store-btn"
                  href={`tel:${STORE_CONTACT.phone}`}
                  className="py-3 px-3 rounded-xl font-bold text-xs bg-slate-100 text-slate-800 hover:bg-slate-200 border border-slate-300 flex items-center justify-center space-x-1.5 transition-colors"
                >
                  <PhoneCall className="w-4 h-4 text-slate-700" />
                  <span>Call Store</span>
                </a>
              </div>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};
