import React, { useState } from 'react';
import { 
  X, 
  Plus, 
  Trash2, 
  Edit3, 
  Check, 
  MessageSquare, 
  Lock, 
  ShieldCheck, 
  Package, 
  Inbox, 
  Star, 
  RotateCcw,
  Sparkles,
  Phone
} from 'lucide-react';
import { Product, ProductCategory, InquiryItem, Review } from '../types';
import { buildWhatsAppUrl } from '../utils/whatsapp';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onAddProduct: (product: Product) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  onResetProducts: () => void;
  inquiries: InquiryItem[];
  onUpdateInquiryStatus: (inquiryId: string, status: 'new' | 'contacted' | 'completed') => void;
  reviews: Review[];
  onDeleteReview: (reviewId: string) => void;
}

export const AdminModal: React.FC<AdminModalProps> = ({
  isOpen,
  onClose,
  products,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onResetProducts,
  inquiries,
  onUpdateInquiryStatus,
  reviews,
  onDeleteReview
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [pinCode, setPinCode] = useState('');
  const [activeTab, setActiveTab] = useState<'products' | 'inquiries' | 'reviews'>('products');
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);

  // Form states for adding/editing product
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState<ProductCategory>('led-headlights');
  const [formPrice, setFormPrice] = useState(4999);
  const [formOrigPrice, setFormOrigPrice] = useState(6999);
  const [formImage, setFormImage] = useState('');
  const [formBadge, setFormBadge] = useState('New Arrival');
  const [formShortDesc, setFormShortDesc] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formWarranty, setFormWarranty] = useState('2 Years Replacement Warranty');
  const [formTime, setFormTime] = useState('45 mins');
  const [formCar, setFormCar] = useState('Universal');

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Simple admin unlock PIN for Ankit Kumar
    if (pinCode.trim().toLowerCase() === '3aauto' || pinCode.trim() === '1234' || pinCode.trim().toLowerCase() === 'ankit') {
      setIsAuthenticated(true);
    } else {
      alert('Invalid Admin PIN. (Default PIN: 3aauto or 1234)');
    }
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    const categoryNames: Record<ProductCategory, string> = {
      'all': 'All Items',
      'led-headlights': 'LED Headlights',
      'fog-lamps': 'Fog Lamps',
      'temple-flags': 'Temple Flags',
      'interior-accessories': 'Interior Accessories',
      'exterior-accessories': 'Exterior Accessories',
      'modification-parts': 'Modification Parts',
      'car-care': 'Car Care Products'
    };

    const newProduct: Product = {
      id: editingProductId || `prod-${Date.now()}`,
      name: formName.trim(),
      category: formCategory,
      categoryName: categoryNames[formCategory] || 'Accessories',
      price: Number(formPrice),
      originalPrice: Number(formOrigPrice),
      rating: 5.0,
      reviewsCount: 1,
      image: formImage.trim() || 'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?auto=format&fit=crop&w=800&q=80',
      gallery: [
        formImage.trim() || 'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?auto=format&fit=crop&w=1200&q=80'
      ],
      inStock: true,
      featured: true,
      badge: formBadge.trim() || undefined,
      shortDesc: formShortDesc.trim() || 'Premium grade car accessory with zero wire cut fitment.',
      description: formDesc.trim() || 'High performance automotive accessory with long durability and OEM finish.',
      specs: {
        'Category': categoryNames[formCategory],
        'Fitment': formCar.trim() || 'Universal',
        'Warranty': formWarranty.trim(),
        'Installation': formTime.trim()
      },
      compatibleCars: [formCar.trim() || 'Universal'],
      installationTime: formTime.trim() || '30 mins',
      warranty: formWarranty.trim() || '1 Year Warranty'
    };

    if (editingProductId) {
      onUpdateProduct(newProduct);
    } else {
      onAddProduct(newProduct);
    }

    setIsAddingProduct(false);
    setEditingProductId(null);
    resetForm();
  };

  const startEditProduct = (prod: Product) => {
    setEditingProductId(prod.id);
    setFormName(prod.name);
    setFormCategory(prod.category);
    setFormPrice(prod.price);
    setFormOrigPrice(prod.originalPrice);
    setFormImage(prod.image);
    setFormBadge(prod.badge || '');
    setFormShortDesc(prod.shortDesc);
    setFormDesc(prod.description);
    setFormWarranty(prod.warranty);
    setFormTime(prod.installationTime);
    setFormCar(prod.compatibleCars[0] || 'Universal');
    setIsAddingProduct(true);
  };

  const resetForm = () => {
    setFormName('');
    setFormCategory('led-headlights');
    setFormPrice(4999);
    setFormOrigPrice(6999);
    setFormImage('');
    setFormBadge('New Arrival');
    setFormShortDesc('');
    setFormDesc('');
    setFormWarranty('2 Years Replacement Warranty');
    setFormTime('45 mins');
    setFormCar('Universal');
  };

  return (
    <div 
      className="fixed inset-0 z-50 overflow-y-auto bg-[#001F3F]/70 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        className="relative bg-white/95 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto border border-white/90"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 bg-[#001F3F] text-white flex items-center justify-between border-b border-[#D4AF37]/30">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center border border-[#D4AF37]/40">
              <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
            </div>
            <div>
              <h3 className="font-bold text-base font-serif">3A Auto Accessories • Store Admin</h3>
              <p className="text-[11px] text-slate-300">Manager: Ankit Kumar</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {!isAuthenticated ? (
          /* Login PIN Prompt */
          <div className="p-8 sm:p-12 text-center max-w-sm mx-auto space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-50 text-[#D4AF37] flex items-center justify-center mx-auto border border-[#D4AF37]/30 shadow-xs">
              <Lock className="w-7 h-7" />
            </div>
            <h4 className="font-bold text-[#001F3F] font-serif text-lg">Admin Login</h4>
            <p className="text-xs text-slate-500">
              Enter Store PIN to manage products, view incoming inquiries, and manage catalog. (PIN: <span className="font-bold text-slate-800">3aauto</span> or <span className="font-bold text-slate-800">1234</span>)
            </p>
            <form onSubmit={handleLogin} className="space-y-3 pt-2">
              <input
                type="password"
                placeholder="Enter PIN (e.g. 3aauto)"
                value={pinCode}
                onChange={(e) => setPinCode(e.target.value)}
                className="w-full text-center text-sm px-4 py-2.5 bg-slate-50 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-[#D4AF37] focus:outline-none"
              />
              <button
                type="submit"
                className="w-full bg-[#001F3F] hover:bg-[#0A3663] text-[#D4AF37] font-bold py-2.5 rounded-xl text-xs shadow-md border border-[#D4AF37]/40 transition-all"
              >
                Unlock Admin Portal
              </button>
            </form>
          </div>
        ) : (
          /* Authenticated Dashboard */
          <div className="p-5 sm:p-7 space-y-6">
            
            {/* Top Navigation Tabs */}
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {
                    setActiveTab('products');
                    setIsAddingProduct(false);
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                    activeTab === 'products'
                      ? 'bg-[#001F3F] text-[#D4AF37] shadow-md border border-[#D4AF37]/40'
                      : 'bg-slate-100/80 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <Package className="w-4 h-4" />
                  <span>Products ({products.length})</span>
                </button>
                <button
                  onClick={() => setActiveTab('inquiries')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                    activeTab === 'inquiries'
                      ? 'bg-[#001F3F] text-[#D4AF37] shadow-md border border-[#D4AF37]/40'
                      : 'bg-slate-100/80 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <Inbox className="w-4 h-4" />
                  <span>Customer Inquiries ({inquiries.length})</span>
                </button>
                <button
                  onClick={() => setActiveTab('reviews')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                    activeTab === 'reviews'
                      ? 'bg-[#001F3F] text-[#D4AF37] shadow-md border border-[#D4AF37]/40'
                      : 'bg-slate-100/80 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <Star className="w-4 h-4" />
                  <span>Reviews ({reviews.length})</span>
                </button>
              </div>

              {activeTab === 'products' && !isAddingProduct && (
                <button
                  onClick={() => {
                    resetForm();
                    setEditingProductId(null);
                    setIsAddingProduct(true);
                  }}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl flex items-center space-x-1.5 shadow-sm border border-emerald-400/40"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New Product</span>
                </button>
              )}
            </div>

            {/* TAB 1: PRODUCTS MANAGER */}
            {activeTab === 'products' && (
              <div>
                {isAddingProduct ? (
                  /* Add / Edit Form */
                  <form onSubmit={handleSaveProduct} className="bg-slate-50/90 backdrop-blur-xs p-5 rounded-2xl border border-slate-200 space-y-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-bold text-sm font-serif text-[#001F3F]">
                        {editingProductId ? 'Edit Product' : 'Add New Car Accessory'}
                      </h4>
                      <button
                        type="button"
                        onClick={() => setIsAddingProduct(false)}
                        className="text-xs text-slate-500 hover:text-slate-800"
                      >
                        Cancel
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Product Title *</label>
                        <input
                          type="text"
                          required
                          value={formName}
                          onChange={(e) => setFormName(e.target.value)}
                          placeholder="e.g. 200W Laser LED Fog Light Kit"
                          className="w-full text-xs px-3 py-2 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Category</label>
                        <select
                          value={formCategory}
                          onChange={(e) => setFormCategory(e.target.value as ProductCategory)}
                          className="w-full text-xs px-3 py-2 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                        >
                          <option value="led-headlights">LED Headlights</option>
                          <option value="fog-lamps">Fog Lamps</option>
                          <option value="temple-flags">Temple Flags</option>
                          <option value="interior-accessories">Interior Accessories</option>
                          <option value="exterior-accessories">Exterior Accessories</option>
                          <option value="modification-parts">Modification Parts</option>
                          <option value="car-care">Car Care Products</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Offer Price (₹) *</label>
                        <input
                          type="number"
                          required
                          value={formPrice}
                          onChange={(e) => setFormPrice(Number(e.target.value))}
                          className="w-full text-xs px-3 py-2 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">MRP Price (₹) *</label>
                        <input
                          type="number"
                          required
                          value={formOrigPrice}
                          onChange={(e) => setFormOrigPrice(Number(e.target.value))}
                          className="w-full text-xs px-3 py-2 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Highlight Badge</label>
                        <input
                          type="text"
                          value={formBadge}
                          onChange={(e) => setFormBadge(e.target.value)}
                          placeholder="e.g. Best Seller / Trending"
                          className="w-full text-xs px-3 py-2 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Image URL</label>
                      <input
                        type="url"
                        value={formImage}
                        onChange={(e) => setFormImage(e.target.value)}
                        placeholder="https://images.unsplash.com/photo-..."
                        className="w-full text-xs px-3 py-2 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Short Description</label>
                      <input
                        type="text"
                        value={formShortDesc}
                        onChange={(e) => setFormShortDesc(e.target.value)}
                        placeholder="Key highlight for product cards..."
                        className="w-full text-xs px-3 py-2 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Compatible Vehicle</label>
                        <input
                          type="text"
                          value={formCar}
                          onChange={(e) => setFormCar(e.target.value)}
                          placeholder="e.g. Universal / Thar / Creta"
                          className="w-full text-xs px-3 py-2 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Fitment Time</label>
                        <input
                          type="text"
                          value={formTime}
                          onChange={(e) => setFormTime(e.target.value)}
                          placeholder="e.g. 45 mins"
                          className="w-full text-xs px-3 py-2 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Warranty Term</label>
                        <input
                          type="text"
                          value={formWarranty}
                          onChange={(e) => setFormWarranty(e.target.value)}
                          placeholder="e.g. 2 Years Replacement"
                          className="w-full text-xs px-3 py-2 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-[#001F3F] hover:bg-[#0A3663] text-[#D4AF37] font-bold py-2.5 rounded-xl text-xs shadow-md border border-[#D4AF37]/40 transition-all"
                    >
                      {editingProductId ? 'Update Product Details' : 'Publish Product to Live Website'}
                    </button>
                  </form>
                ) : (
                  /* Products Table */
                  <div className="space-y-3">
                    <div className="bg-slate-50/80 backdrop-blur-xs rounded-2xl border border-slate-200 overflow-hidden divide-y divide-slate-200 text-xs">
                      {products.map((prod) => (
                        <div key={prod.id} className="p-3.5 flex items-center justify-between hover:bg-white transition-colors">
                          <div className="flex items-center space-x-3 min-w-0">
                            <img src={prod.image} alt={prod.name} className="w-12 h-12 rounded-xl object-cover border border-slate-200 shrink-0" />
                            <div className="min-w-0">
                              <h5 className="font-bold text-[#001F3F] truncate">{prod.name}</h5>
                              <p className="text-slate-500 text-[11px]">{prod.categoryName} • ₹{prod.price.toLocaleString('en-IN')}</p>
                            </div>
                          </div>

                          <div className="flex items-center space-x-2 shrink-0">
                            <button
                              onClick={() => startEditProduct(prod)}
                              className="p-1.5 rounded-lg text-slate-600 hover:text-[#001F3F] hover:bg-slate-100"
                              title="Edit product"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => onDeleteProduct(prod.id)}
                              className="p-1.5 rounded-lg text-rose-500 hover:text-rose-700 hover:bg-rose-50"
                              title="Delete product"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="flex justify-end pt-2">
                      <button
                        onClick={onResetProducts}
                        className="text-xs text-slate-400 hover:text-rose-600 flex items-center"
                      >
                        <RotateCcw className="w-3.5 h-3.5 mr-1" />
                        Reset All Products to Factory Default
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: INQUIRIES VIEWER */}
            {activeTab === 'inquiries' && (
              <div className="space-y-3">
                {inquiries.length === 0 ? (
                  <p className="text-center py-8 text-xs text-slate-500">No customer inquiries submitted yet.</p>
                ) : (
                  <div className="space-y-3">
                    {inquiries.map((inq) => (
                      <div key={inq.id} className="p-4 bg-slate-50/80 backdrop-blur-xs rounded-2xl border border-slate-200 space-y-2 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-sm text-[#001F3F]">{inq.customerName}</span>
                          <span className={`px-2 py-0.5 rounded-full font-semibold uppercase text-[10px] ${
                            inq.status === 'completed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : inq.status === 'contacted'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-[#001F3F]'
                          }`}>
                            {inq.status}
                          </span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-slate-600">
                          <div>📞 Phone: <span className="font-semibold text-slate-900">{inq.phoneNumber}</span></div>
                          <div>🚘 Vehicle: <span className="font-semibold text-slate-900">{inq.carModel}</span></div>
                          <div>🔧 Interest: <span className="font-semibold text-slate-900">{inq.selectedCategory}</span></div>
                          <div>📅 Preferred Date: <span className="font-semibold text-slate-900">{inq.preferredDate}</span></div>
                        </div>
                        {inq.message && (
                          <p className="p-2 bg-white rounded-xl border border-slate-200 text-slate-700 italic">
                            "{inq.message}"
                          </p>
                        )}
                        <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                          <a
                            href={buildWhatsAppUrl(`Hi ${inq.customerName}, this is Ankit Kumar from 3A Auto Accessories regarding your inquiry for ${inq.carModel}.`, inq.phoneNumber)}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded-xl flex items-center space-x-1 border border-emerald-400/40"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>Reply via WhatsApp</span>
                          </a>

                          <div className="flex space-x-1">
                            <button
                              onClick={() => onUpdateInquiryStatus(inq.id, 'contacted')}
                              className="px-2 py-1 bg-blue-50 text-blue-700 rounded-lg font-semibold"
                            >
                              Mark Contacted
                            </button>
                            <button
                              onClick={() => onUpdateInquiryStatus(inq.id, 'completed')}
                              className="px-2 py-1 bg-emerald-50 text-emerald-700 rounded-lg font-semibold"
                            >
                              Mark Completed
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: REVIEWS MANAGER */}
            {activeTab === 'reviews' && (
              <div className="space-y-3">
                {reviews.map((rev) => (
                  <div key={rev.id} className="p-4 bg-slate-50/80 backdrop-blur-xs rounded-2xl border border-slate-200 flex items-start justify-between text-xs">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-[#001F3F]">{rev.author}</span>
                        <span className="text-[#D4AF37] font-bold">{'★'.repeat(rev.rating)}</span>
                        <span className="text-slate-400 text-[11px]">{rev.carModel}</span>
                      </div>
                      <p className="text-slate-600 mt-1 italic">"{rev.comment}"</p>
                    </div>
                    <button
                      onClick={() => onDeleteReview(rev.id)}
                      className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg"
                      title="Delete review"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
};
