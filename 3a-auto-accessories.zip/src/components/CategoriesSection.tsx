import React from 'react';
import { 
  Lightbulb, 
  Flame, 
  Sparkles, 
  CarFront, 
  Wrench, 
  SprayCan, 
  ArrowUpRight,
  CloudFog
} from 'lucide-react';
import { CATEGORIES } from '../data/categories';
import { ProductCategory } from '../types';

interface CategoriesSectionProps {
  onSelectCategory: (categoryId: ProductCategory) => void;
}

export const CategoriesSection: React.FC<CategoriesSectionProps> = ({ onSelectCategory }) => {
  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Lightbulb':
        return <Lightbulb className="w-6 h-6 text-amber-500" />;
      case 'CloudFog':
        return <CloudFog className="w-6 h-6 text-cyan-500" />;
      case 'Flame':
        return <Flame className="w-6 h-6 text-amber-500" />;
      case 'Sparkles':
        return <Sparkles className="w-6 h-6 text-indigo-500" />;
      case 'CarFront':
        return <CarFront className="w-6 h-6 text-blue-500" />;
      case 'Wrench':
        return <Wrench className="w-6 h-6 text-emerald-500" />;
      case 'SprayCan':
        return <SprayCan className="w-6 h-6 text-rose-500" />;
      default:
        return <Sparkles className="w-6 h-6 text-amber-500" />;
    }
  };

  return (
    <section id="categories-section" className="py-16 sm:py-20 bg-slate-50/60 backdrop-blur-md border-b border-slate-200/60 relative">
      {/* Frosted ambient background elements */}
      <div className="absolute top-10 right-10 w-96 h-96 bg-amber-200/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-sky-200/20 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <div className="inline-flex items-center space-x-2 bg-white/80 border border-[#D4AF37]/40 text-[#001F3F] rounded-full px-3.5 py-1 text-xs font-semibold uppercase tracking-wider mb-2 backdrop-blur-md shadow-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]"></span>
              <span>Top Collections</span>
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold font-serif text-[#001F3F] tracking-tight">
              Featured Categories
            </h2>
            <p className="text-slate-600 text-sm sm:text-base mt-2 max-w-xl">
              Explore curated aftermarket upgrades engineered for high performance, luxury aesthetics, and supreme durability.
            </p>
          </div>

          <button
            onClick={() => onSelectCategory('all')}
            className="mt-4 md:mt-0 inline-flex items-center text-sm font-bold text-[#001F3F] hover:text-[#D4AF37] transition-colors group px-4 py-2 rounded-xl bg-white/70 backdrop-blur-md border border-slate-200/70 shadow-xs hover:border-[#D4AF37]/50"
          >
            <span>View Complete Inventory</span>
            <ArrowUpRight className="w-4 h-4 ml-1 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform text-[#D4AF37]" />
          </button>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {CATEGORIES.map((category) => (
            <div
              key={category.id}
              onClick={() => onSelectCategory(category.id)}
              className="group relative bg-white/70 hover:bg-white/95 backdrop-blur-md rounded-2xl p-6 border border-white/80 hover:border-[#D4AF37]/80 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer overflow-hidden flex flex-col justify-between"
            >
              {/* Top Row: Icon + Product Count Badge */}
              <div className="flex items-center justify-between mb-5">
                <div className="w-13 h-13 rounded-xl bg-white/90 group-hover:bg-[#001F3F] border border-slate-200/80 group-hover:border-[#001F3F] shadow-sm flex items-center justify-center p-3 transition-colors duration-300 backdrop-blur-md">
                  {getCategoryIcon(category.icon)}
                </div>
                <span className="text-xs font-semibold text-slate-600 bg-white/80 group-hover:bg-amber-100/90 group-hover:text-amber-900 px-3 py-1 rounded-full border border-slate-200/80 backdrop-blur-md transition-colors shadow-2xs">
                  {category.count}+ Options
                </span>
              </div>

              {/* Title & Tagline */}
              <div>
                <h3 className="text-lg font-bold text-[#001F3F] group-hover:text-[#D4AF37] transition-colors font-serif">
                  {category.name}
                </h3>
                <p className="text-xs text-amber-700 font-medium mt-0.5">
                  {category.tagline}
                </p>
                <p className="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                  {category.description}
                </p>
              </div>

              {/* Bottom Action Footer */}
              <div className="mt-5 pt-4 border-t border-slate-200/60 flex items-center justify-between text-xs font-bold text-[#001F3F] group-hover:text-[#D4AF37]">
                <span>Explore Products</span>
                <div className="w-7 h-7 rounded-full bg-white/90 group-hover:bg-[#D4AF37] group-hover:text-[#001F3F] flex items-center justify-center transition-all duration-300 shadow-xs border border-slate-200/60">
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </div>
              </div>

              {/* Subtle gold accent border at bottom on hover */}
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[#D4AF37] to-amber-300 scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left" />
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
