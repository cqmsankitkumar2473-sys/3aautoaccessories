import React from 'react';
import { 
  Sparkles, 
  MessageSquare, 
  ArrowRight, 
  ShieldCheck, 
  Zap, 
  CheckCircle2, 
  Award,
  ChevronRight
} from 'lucide-react';
import { STORE_CONTACT, buildWhatsAppUrl, getGeneralInquiryMessage } from '../utils/whatsapp';

interface HeroProps {
  onExploreProducts: () => void;
  onExplorePackages: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreProducts, onExplorePackages }) => {
  return (
    <section id="hero-section" className="relative overflow-hidden bg-gradient-to-b from-[#001329] via-[#001F3F] to-[#00142A] text-white pt-8 pb-16 lg:pt-14 lg:pb-24">
      {/* Subtle Background Lighting & Frosted Grid Texture */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(212,175,55,0.15),transparent_45%)] pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_80%,rgba(0,102,204,0.2),transparent_50%)] pointer-events-none" />
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          
          {/* Left Column: Headline, Subheading, Badges, CTAs */}
          <div className="lg:col-span-7 space-y-6 text-left">
            
            {/* Owner & Quality Stamp Pill (Frosted Glass) */}
            <div className="inline-flex items-center space-x-2 bg-white/10 border border-[#D4AF37]/50 rounded-full px-3.5 py-1.5 backdrop-blur-xl shadow-lg shadow-black/20">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#D4AF37] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#D4AF37]"></span>
              </span>
              <span className="text-xs font-semibold text-[#D4AF37] tracking-wide uppercase">
                3A Auto Accessories • ANKIT KUMAR
              </span>
              <span className="text-slate-300 text-xs hidden sm:inline">• Certified Master Installer</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold font-serif tracking-tight leading-[1.15] text-white">
              Upgrade Your Drive with{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-100 via-[#D4AF37] to-amber-400 underline decoration-[#D4AF37]/50 underline-offset-8">
                Premium Auto Accessories
              </span>
            </h1>

            {/* Exact Sub Heading */}
            <p className="text-base sm:text-lg md:text-xl text-slate-200/90 font-normal leading-relaxed max-w-2xl">
              High-quality car accessories and custom modification parts designed to enhance style, comfort, and performance.
            </p>

            {/* Trust Highlights Checklist */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 text-xs sm:text-sm text-slate-200 font-medium">
              <div className="flex items-center space-x-2 bg-white/5 backdrop-blur-md px-3 py-2 rounded-xl border border-white/10">
                <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>Zero Wire-Cut Fitment</span>
              </div>
              <div className="flex items-center space-x-2 bg-white/5 backdrop-blur-md px-3 py-2 rounded-xl border border-white/10">
                <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>100% Genuine Warranty</span>
              </div>
              <div className="flex items-center space-x-2 bg-white/5 backdrop-blur-md px-3 py-2 rounded-xl border border-white/10">
                <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>Direct Dealer Pricing</span>
              </div>
            </div>

            {/* CTAs: Explore Products & WhatsApp Us */}
            <div className="pt-3 flex flex-wrap items-center gap-4">
              <button
                id="hero-explore-products-btn"
                onClick={onExploreProducts}
                className="inline-flex items-center space-x-2.5 bg-gradient-to-r from-[#D4AF37] via-amber-400 to-[#D4AF37] hover:from-amber-300 hover:to-amber-400 text-[#001F3F] font-bold px-7 py-3.5 rounded-xl shadow-xl shadow-amber-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 text-base border border-amber-300/40"
              >
                <span>🚗 Explore Products</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                id="hero-whatsapp-btn"
                href={buildWhatsAppUrl(getGeneralInquiryMessage())}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-2.5 bg-emerald-600/90 hover:bg-emerald-500 text-white font-bold px-7 py-3.5 rounded-xl shadow-xl shadow-emerald-950/40 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 border border-emerald-400/40 text-base group backdrop-blur-md"
              >
                <MessageSquare className="w-5 h-5 text-white group-hover:rotate-12 transition-transform" />
                <span>💬 WhatsApp Us</span>
              </a>
            </div>

            {/* Quick Consultation Badge */}
            <div className="flex items-center space-x-3 pt-2 text-xs text-slate-300">
              <span className="flex items-center text-[#D4AF37]">
                <Zap className="w-3.5 h-3.5 mr-1" />
                Instant fitment advice & pricing directly from Ankit Kumar
              </span>
            </div>
          </div>

          {/* Right Column: Luxury Automotive Visual with Interactive Floating Frosted Cards */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Glowing Aura backdrop */}
              <div className="absolute -inset-1.5 bg-gradient-to-r from-[#D4AF37] to-cyan-500 rounded-3xl blur-xl opacity-35 group-hover:opacity-60 transition duration-1000"></div>

              {/* Main Visual Image Card */}
              <div className="relative rounded-3xl overflow-hidden border border-white/20 bg-slate-900/80 backdrop-blur-md shadow-2xl">
                <img 
                  src="https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=900&q=80" 
                  alt="3A Auto Accessories Luxury Car LED and Custom Modifications" 
                  className="w-full h-80 sm:h-96 object-cover hover:scale-105 transition-transform duration-700"
                />

                {/* Dark Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#001F3F] via-transparent to-transparent"></div>

                {/* Top Badge (Frosted Glass) */}
                <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-xl border border-[#D4AF37]/50 px-3 py-1.5 rounded-xl text-xs font-semibold text-[#D4AF37] flex items-center shadow-lg">
                  <Sparkles className="w-3.5 h-3.5 mr-1.5 text-[#D4AF37]" />
                  2026 High-Performance Edition
                </div>

                {/* Bottom Overlay Info (Frosted Glass) */}
                <div className="absolute bottom-4 left-4 right-4 p-3.5 bg-white/10 backdrop-blur-xl rounded-2xl border border-white/20 flex items-center justify-between shadow-lg">
                  <div>
                    <h2 className="text-sm font-bold text-white">AlphaBeam 180W Matrix & Symphony Lights</h2>
                    <p className="text-xs text-[#D4AF37] font-medium">Available for all SUVs & Sedans</p>
                  </div>
                  <button
                    onClick={onExplorePackages}
                    className="p-2 bg-[#D4AF37] hover:bg-amber-300 text-[#001F3F] rounded-xl text-xs font-bold flex items-center transition-colors shrink-0 shadow-md"
                    title="View Modification Packages"
                  >
                    View Packs <ChevronRight className="w-3 h-3 ml-0.5" />
                  </button>
                </div>
              </div>

              {/* Floating Stat Card 1: 5.0 Star Rated (Frosted Glass) */}
              <div className="absolute -bottom-5 -left-4 sm:-left-6 bg-[#001F3F]/85 backdrop-blur-xl border border-[#D4AF37]/50 p-3.5 rounded-2xl shadow-2xl flex items-center space-x-3 max-w-[210px]">
                <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center shrink-0">
                  <Award className="w-5 h-5 text-[#D4AF37]" />
                </div>
                <div>
                  <div className="flex items-center text-[#D4AF37] text-xs font-bold">
                    <span>⭐⭐⭐⭐⭐</span>
                    <span className="ml-1 text-white">5.0</span>
                  </div>
                  <p className="text-[11px] text-slate-200 font-medium">500+ Verified Upgrades</p>
                </div>
              </div>

              {/* Floating Stat Card 2: Zero Wire Cut Guarantee (Frosted Glass) */}
              <div className="absolute -top-4 -right-4 sm:-right-6 bg-[#001F3F]/85 backdrop-blur-xl border border-emerald-400/50 p-3.5 rounded-2xl shadow-2xl flex items-center space-x-3 hidden sm:flex">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/40 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <p className="text-xs font-bold text-white">OEM Car Warranty Safe</p>
                  <p className="text-[11px] text-emerald-300 font-medium">Coupler to Coupler Fit</p>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
