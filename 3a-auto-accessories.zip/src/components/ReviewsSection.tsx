import React, { useState } from 'react';
import { 
  Star, 
  CheckCircle2, 
  Quote, 
  MessageSquarePlus, 
  X, 
  Send, 
  Award,
  Sparkles,
  MapPin,
  Car
} from 'lucide-react';
import { Review } from '../types';
import confetti from 'canvas-confetti';

interface ReviewsSectionProps {
  reviews: Review[];
  onAddReview: (review: Review) => void;
}

export const ReviewsSection: React.FC<ReviewsSectionProps> = ({ reviews, onAddReview }) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [newAuthor, setNewAuthor] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [newCarModel, setNewCarModel] = useState('');
  const [newLocation, setNewLocation] = useState('');
  const [newProduct, setNewProduct] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor.trim() || !newComment.trim()) return;

    const review: Review = {
      id: `rev-${Date.now()}`,
      author: newAuthor.trim(),
      rating: newRating,
      date: 'Just now',
      comment: newComment.trim(),
      carModel: newCarModel.trim() || 'Verified Vehicle Owner',
      productPurchased: newProduct.trim() || 'Custom Car Accessories',
      verified: true,
      location: newLocation.trim() || 'India'
    };

    onAddReview(review);
    setSubmitted(true);

    try {
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.7 }
      });
    } catch (_) {}

    setTimeout(() => {
      setSubmitted(false);
      setModalOpen(false);
      setNewAuthor('');
      setNewComment('');
      setNewCarModel('');
      setNewLocation('');
      setNewProduct('');
    }, 1500);
  };

  return (
    <section id="reviews-section" className="py-16 sm:py-24 bg-slate-100/50 backdrop-blur-md border-b border-slate-200/60 relative">
      {/* Background glow */}
      <div className="absolute top-20 right-1/3 w-80 h-80 bg-amber-100/30 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <div className="inline-flex items-center space-x-2 bg-white/80 border border-[#D4AF37]/50 text-[#001F3F] rounded-full px-3.5 py-1 text-xs font-semibold uppercase tracking-wider mb-2 backdrop-blur-md shadow-xs">
              <Award className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Real Customer Stories</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold font-serif text-[#001F3F] tracking-tight">
              Customer Reviews & Ratings
            </h2>
            <div className="flex items-center space-x-2 mt-2">
              <div className="flex text-[#D4AF37]">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-[#D4AF37] text-[#D4AF37]" />
                ))}
              </div>
              <span className="font-extrabold text-slate-900 text-base">5.0 / 5.0</span>
              <span className="text-slate-500 text-sm">• 100% Genuine Car Enthusiast Feedback</span>
            </div>
          </div>

          <button
            onClick={() => setModalOpen(true)}
            className="mt-4 md:mt-0 inline-flex items-center space-x-2 bg-[#001F3F] hover:bg-[#0A3663] text-[#D4AF37] px-5 py-3 rounded-xl font-bold text-xs shadow-md transition-all border border-[#D4AF37]/40 backdrop-blur-md"
          >
            <MessageSquarePlus className="w-4 h-4" />
            <span>Write a Review</span>
          </button>
        </div>

        {/* Highlighted Quote Banners (Frosted Glass) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
          <div className="bg-gradient-to-r from-[#D4AF37] via-amber-400 to-[#D4AF37] text-[#001F3F] p-6 sm:p-7 rounded-3xl shadow-xl flex items-start space-x-4 border border-amber-300/60 backdrop-blur-md">
            <Quote className="w-9 h-9 text-[#001F3F]/30 shrink-0 mt-1" />
            <div>
              <div className="flex text-[#001F3F] mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-[#001F3F] text-[#001F3F]" />
                ))}
              </div>
              <p className="text-base sm:text-lg font-bold font-serif leading-snug">
                "Excellent quality and fast installation. Highly recommended!"
              </p>
              <p className="text-xs font-bold text-[#001F3F]/80 mt-2">
                Verified Mahindra Thar Upgrade • 3A Auto Accessories
              </p>
            </div>
          </div>

          <div className="bg-[#001F3F]/95 text-white p-6 sm:p-7 rounded-3xl shadow-xl border border-[#D4AF37]/40 flex items-start space-x-4 backdrop-blur-xl">
            <Quote className="w-9 h-9 text-[#D4AF37]/40 shrink-0 mt-1" />
            <div>
              <div className="flex text-[#D4AF37] mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-[#D4AF37] text-[#D4AF37]" />
                ))}
              </div>
              <p className="text-base sm:text-lg font-bold font-serif text-[#D4AF37] leading-snug">
                "Best place for premium car accessories."
              </p>
              <p className="text-xs font-medium text-slate-200 mt-2">
                Verified Hyundai Creta 2K Android CarPlay & Ambient Light Setup
              </p>
            </div>
          </div>
        </div>

        {/* Reviews Grid (Frosted Glass Cards) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {reviews.map((rev) => (
            <div
              key={rev.id}
              className="bg-white/75 hover:bg-white/95 backdrop-blur-md rounded-3xl p-6 border border-white/80 hover:border-[#D4AF37]/50 shadow-sm hover:shadow-xl transition-all flex flex-col justify-between"
            >
              <div>
                {/* Rating & Date */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex text-[#D4AF37]">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#D4AF37] text-[#D4AF37]" />
                    ))}
                  </div>
                  <span className="text-xs text-slate-400 font-medium">{rev.date}</span>
                </div>

                {/* Comment */}
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>

              {/* Author & Car Info */}
              <div className="mt-5 pt-4 border-t border-slate-100 flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-[#001F3F] text-[#D4AF37] flex items-center justify-center font-bold text-sm shrink-0 border border-[#D4AF37]/40 shadow-xs">
                  {rev.author.charAt(0)}
                </div>
                <div className="overflow-hidden">
                  <div className="flex items-center space-x-1.5">
                    <h4 className="text-xs font-bold text-slate-900 truncate">
                      {rev.author}
                    </h4>
                    {rev.verified && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" title="Verified Customer" />
                    )}
                  </div>
                  <div className="flex items-center text-[11px] text-slate-500 truncate mt-0.5">
                    <Car className="w-3 h-3 mr-1 text-[#D4AF37] shrink-0" />
                    <span className="truncate">{rev.carModel}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Add Review Modal (Frosted Glass) */}
        {modalOpen && (
          <div 
            className="fixed inset-0 z-50 bg-[#00142A]/80 backdrop-blur-xl flex items-center justify-center p-4"
            onClick={() => setModalOpen(false)}
          >
            <div
              className="bg-white/95 backdrop-blur-2xl rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl border border-white/80 relative"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setModalOpen(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1"
              >
                <X className="w-5 h-5" />
              </button>

              <h3 className="text-xl font-bold font-serif text-[#001F3F] mb-1">
                Share Your Experience
              </h3>
              <p className="text-xs text-slate-500 mb-5">
                Your review helps other car owners make informed choices for accessories & modifications.
              </p>

              {submitted ? (
                <div className="py-8 text-center text-emerald-600">
                  <CheckCircle2 className="w-12 h-12 mx-auto mb-2 text-emerald-500 animate-bounce" />
                  <p className="font-bold text-base">Thank you for your review!</p>
                  <p className="text-xs text-slate-500">Your feedback has been published.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Your Rating
                    </label>
                    <div className="flex items-center space-x-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          type="button"
                          key={star}
                          onClick={() => setNewRating(star)}
                          className="p-1 text-[#D4AF37] focus:outline-none"
                        >
                          <Star
                            className={`w-7 h-7 ${
                              star <= newRating
                                ? 'fill-[#D4AF37] text-[#D4AF37]'
                                : 'text-slate-200'
                            }`}
                          />
                        </button>
                      ))}
                      <span className="text-xs font-bold text-slate-700 ml-2">
                        {newRating} / 5 Stars
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Your Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Ankit Sharma"
                        value={newAuthor}
                        onChange={(e) => setNewAuthor(e.target.value)}
                        className="w-full text-xs px-3 py-2.5 bg-white rounded-xl border border-slate-200 focus:ring-2 focus:ring-[#D4AF37] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Car Make & Model
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Mahindra Thar / Creta"
                        value={newCarModel}
                        onChange={(e) => setNewCarModel(e.target.value)}
                        className="w-full text-xs px-3 py-2.5 bg-white rounded-xl border border-slate-200 focus:ring-2 focus:ring-[#D4AF37] focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Product(s) Installed
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 180W Bi-LED Headlights + 7D Mats"
                      value={newProduct}
                      onChange={(e) => setNewProduct(e.target.value)}
                      className="w-full text-xs px-3 py-2.5 bg-white rounded-xl border border-slate-200 focus:ring-2 focus:ring-[#D4AF37] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Your Review & Feedback *
                    </label>
                    <textarea
                      required
                      rows={3}
                      placeholder="Describe the product performance, lighting output, fitment quality, and service..."
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      className="w-full text-xs p-3 bg-white rounded-xl border border-slate-200 focus:ring-2 focus:ring-[#D4AF37] focus:outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#001F3F] hover:bg-[#0A3663] text-[#D4AF37] font-bold py-3 px-4 rounded-xl text-xs flex items-center justify-center space-x-2 shadow-lg border border-[#D4AF37]/30 transition-colors"
                  >
                    <Send className="w-4 h-4" />
                    <span>Submit Customer Review</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
