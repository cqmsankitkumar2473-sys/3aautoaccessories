import React from 'react';
import { 
  Wrench, 
  Sparkles, 
  Check, 
  MessageSquare, 
  Clock, 
  Car, 
  ArrowRight,
  ShieldAlert
} from 'lucide-react';
import { MODIFICATION_PACKAGES } from '../data/packages';
import { ModificationPackage } from '../types';
import { buildWhatsAppUrl, getPackageInquiryMessage } from '../utils/whatsapp';

interface CustomPackagesSectionProps {
  onSelectPackage?: (pkg: ModificationPackage) => void;
}

export const CustomPackagesSection: React.FC<CustomPackagesSectionProps> = () => {
  const handleBookPackage = (pkg: ModificationPackage) => {
    const url = buildWhatsAppUrl(getPackageInquiryMessage(pkg.name, pkg.packagePrice));
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="packages-section" className="py-16 sm:py-24 bg-gradient-to-b from-[#00142A] via-[#001F3F] to-[#001328] text-white relative overflow-hidden">
      {/* Frosted ambient background elements */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_30%,rgba(212,175,55,0.12),transparent_40%)] pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_70%,rgba(0,102,204,0.15),transparent_50%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center space-x-2 bg-white/10 border border-[#D4AF37]/50 text-[#D4AF37] rounded-full px-3.5 py-1 text-xs font-semibold uppercase tracking-wider mb-3 backdrop-blur-md shadow-lg shadow-black/20">
            <Wrench className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>All-in-One Transformation Kits</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold font-serif text-white tracking-tight">
            Custom Modification Packages
          </h2>
          <p className="text-slate-200/90 text-sm sm:text-base mt-2">
            Save up to ₹14,000 with our expertly matched modification combos. Includes professional fitting and priority bay booking.
          </p>
        </div>

        {/* Packages Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {MODIFICATION_PACKAGES.map((pkg, idx) => {
            const isFeatured = idx === 1; // Middle package highlight
            return (
              <div
                key={pkg.id}
                className={`relative rounded-3xl overflow-hidden transition-all duration-300 flex flex-col justify-between backdrop-blur-xl ${
                  isFeatured
                    ? 'bg-[#002247]/85 border-2 border-[#D4AF37] shadow-2xl shadow-amber-500/20 lg:-translate-y-2'
                    : 'bg-[#001730]/75 border border-white/15 shadow-xl hover:border-[#D4AF37]/50'
                }`}
              >
                {/* Top Badge */}
                {isFeatured && (
                  <div className="bg-gradient-to-r from-[#D4AF37] via-amber-400 to-[#D4AF37] text-[#001F3F] font-extrabold text-xs py-2 text-center uppercase tracking-wider shadow-md">
                    ⭐ Most Popular VIP Upgrade
                  </div>
                )}

                <div className="p-6 sm:p-8 space-y-6">
                  
                  {/* Header & Tag */}
                  <div>
                    <span className="text-xs font-bold text-[#D4AF37] uppercase tracking-widest bg-white/10 border border-[#D4AF37]/40 px-3 py-1 rounded-full backdrop-blur-md">
                      {pkg.tier}
                    </span>
                    <h3 className="text-xl sm:text-2xl font-bold font-serif text-white mt-3">
                      {pkg.name}
                    </h3>
                    <p className="text-xs text-slate-300 mt-1.5 flex items-center">
                      <Car className="w-3.5 h-3.5 mr-1 text-[#D4AF37] shrink-0" />
                      <span>{pkg.targetSegment}</span>
                    </p>
                  </div>

                  {/* Pricing Box (Frosted Glass) */}
                  <div className="p-4 rounded-2xl bg-black/40 border border-white/15 backdrop-blur-md">
                    <div className="flex items-baseline justify-between">
                      <div>
                        <span className="text-xs text-slate-300">Combo Price:</span>
                        <div className="flex items-baseline space-x-2">
                          <span className="text-3xl font-black text-[#D4AF37]">
                            ₹{pkg.packagePrice.toLocaleString('en-IN')}
                          </span>
                          <span className="text-sm text-slate-400 line-through">
                            ₹{pkg.originalTotal.toLocaleString('en-IN')}
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2.5 py-1 rounded-lg backdrop-blur-md">
                          {pkg.badge}
                        </span>
                      </div>
                    </div>

                    <div className="mt-3 pt-2 border-t border-white/10 flex items-center justify-between text-xs text-slate-300">
                      <span className="flex items-center">
                        <Clock className="w-3.5 h-3.5 mr-1 text-[#D4AF37]" />
                        Fitment Time: {pkg.estimatedTime}
                      </span>
                      <span className="text-[#D4AF37] font-semibold">Zero Wire-Cut</span>
                    </div>
                  </div>

                  {/* Included Items Checklist */}
                  <div>
                    <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-3">
                      Included In This Combo:
                    </h4>
                    <ul className="space-y-2.5 text-xs text-slate-200">
                      {pkg.itemsIncluded.map((item, i) => (
                        <li key={i} className="flex items-start space-x-2.5">
                          <div className="w-4 h-4 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center shrink-0 mt-0.5 border border-[#D4AF37]/40">
                            <Check className="w-3 h-3 font-bold" />
                          </div>
                          <span className="leading-snug">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                </div>

                {/* Bottom CTA Button */}
                <div className="p-6 sm:p-8 pt-0">
                  <button
                    onClick={() => handleBookPackage(pkg)}
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3.5 px-4 rounded-xl flex items-center justify-center space-x-2 shadow-lg shadow-emerald-950/60 transition-all text-sm group border border-emerald-400/40"
                  >
                    <MessageSquare className="w-4 h-4 group-hover:rotate-12 transition-transform" />
                    <span>Book Package on WhatsApp</span>
                  </button>
                  <p className="text-center text-[11px] text-slate-400 mt-2">
                    Confirmed slot booking with Ankit Kumar
                  </p>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
