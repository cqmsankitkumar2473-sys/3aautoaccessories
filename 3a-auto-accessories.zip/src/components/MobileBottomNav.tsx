import React from 'react';
import { 
  Home, 
  Search, 
  MessageSquare, 
  Phone, 
  ShoppingBag,
  Sparkles
} from 'lucide-react';
import { STORE_CONTACT, buildWhatsAppUrl, getGeneralInquiryMessage } from '../utils/whatsapp';

interface MobileBottomNavProps {
  cartCount: number;
  onOpenCart: () => void;
  onNavigate: (sectionId: string) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  cartCount,
  onOpenCart,
  onNavigate
}) => {
  return (
    <div id="mobile-sticky-bottom-nav" className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/80 backdrop-blur-xl border-t border-white/80 shadow-2xl py-2 px-3">
      <div className="grid grid-cols-4 gap-1 items-center text-center">
        
        {/* Products */}
        <button
          onClick={() => onNavigate('products-section')}
          className="flex flex-col items-center justify-center py-1 text-slate-700 hover:text-[#D4AF37] transition-colors"
        >
          <Search className="w-5 h-5" />
          <span className="text-[10px] font-bold mt-0.5">Catalog</span>
        </button>

        {/* WhatsApp Button */}
        <a
          href={buildWhatsAppUrl(getGeneralInquiryMessage())}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center justify-center py-1 text-emerald-600 font-bold"
        >
          <div className="relative">
            <MessageSquare className="w-5 h-5 fill-emerald-600/20" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
          </div>
          <span className="text-[10px] mt-0.5">WhatsApp</span>
        </a>

        {/* Call Now */}
        <a
          href={`tel:${STORE_CONTACT.phone}`}
          className="flex flex-col items-center justify-center py-1 text-[#001F3F] font-bold hover:text-[#D4AF37] transition-colors"
        >
          <Phone className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">Call Store</span>
        </a>

        {/* Cart / Wishlist */}
        <button
          onClick={onOpenCart}
          className="flex flex-col items-center justify-center py-1 text-slate-700 hover:text-[#D4AF37] transition-colors relative"
        >
          <div className="relative">
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-[#D4AF37] text-[#001F3F] font-black text-[10px] rounded-full w-4 h-4 flex items-center justify-center shadow-xs">
                {cartCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-bold mt-0.5">Quote Cart</span>
        </button>

      </div>
    </div>
  );
};
