import React from 'react';
import { 
  MapPin, 
  Phone, 
  Mail, 
  MessageSquare, 
  Clock, 
  Navigation, 
  ShieldCheck, 
  ExternalLink 
} from 'lucide-react';
import { STORE_CONTACT, buildWhatsAppUrl, getGeneralInquiryMessage } from '../utils/whatsapp';

export const ContactAndMap: React.FC = () => {
  return (
    <section id="contact-section" className="py-16 sm:py-24 bg-white/60 backdrop-blur-md relative">
      {/* Background glow */}
      <div className="absolute top-10 right-10 w-80 h-80 bg-blue-100/30 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center space-x-2 bg-white/80 border border-[#D4AF37]/50 text-[#001F3F] rounded-full px-3.5 py-1 text-xs font-semibold uppercase tracking-wider mb-3 backdrop-blur-md shadow-xs">
            <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Store & Fitting Center</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold font-serif text-[#001F3F] tracking-tight">
            Visit 3A Auto Accessories
          </h2>
          <p className="text-slate-600 text-sm sm:text-base mt-2">
            Experience our products live, inspect light throws in our dark room simulation bay, and get custom fitment by expert technicians.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Contact Details Cards (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            
            {/* Store Address Card (Frosted Glass) */}
            <div className="bg-white/75 hover:bg-white/95 backdrop-blur-md rounded-3xl p-5 border border-white/80 hover:border-[#D4AF37]/60 transition-all shadow-sm">
              <div className="flex items-start space-x-3.5">
                <div className="w-10 h-10 rounded-2xl bg-amber-50 text-[#D4AF37] flex items-center justify-center shrink-0 mt-0.5 border border-[#D4AF37]/40 shadow-xs">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    📍 Store Address
                  </h4>
                  <p className="text-sm font-bold text-[#001F3F] mt-1">
                    {STORE_CONTACT.brandName} (Prop. Ankit Kumar)
                  </p>
                  <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                    {STORE_CONTACT.address}
                  </p>
                  <p className="text-xs text-slate-600 font-medium">
                    {STORE_CONTACT.cityState}
                  </p>
                </div>
              </div>
            </div>

            {/* Phone & WhatsApp Card (Frosted Glass) */}
            <div className="bg-white/75 hover:bg-white/95 backdrop-blur-md rounded-3xl p-5 border border-white/80 hover:border-[#D4AF37]/60 transition-all shadow-sm">
              <div className="flex items-start space-x-3.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5 border border-emerald-300">
                  <Phone className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    📞 Mobile & WhatsApp Support
                  </h4>
                  <div className="flex items-baseline space-x-2 mt-1">
                    <a
                      href={`tel:${STORE_CONTACT.phone}`}
                      className="text-sm sm:text-base font-bold text-[#001F3F] hover:text-[#D4AF37] transition-colors"
                    >
                      {STORE_CONTACT.displayPhone}
                    </a>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Direct Contact: <span className="font-semibold text-slate-800">Ankit Kumar</span>
                  </p>
                  <div className="mt-3 flex gap-2">
                    <a
                      href={`tel:${STORE_CONTACT.phone}`}
                      className="inline-flex items-center space-x-1.5 bg-[#001F3F] hover:bg-[#0A3663] text-white text-xs font-bold px-3.5 py-1.5 rounded-xl shadow-xs border border-white/10"
                    >
                      <Phone className="w-3.5 h-3.5 text-[#D4AF37]" />
                      <span>Call Now</span>
                    </a>
                    <a
                      href={buildWhatsAppUrl(getGeneralInquiryMessage())}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center space-x-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-3.5 py-1.5 rounded-xl shadow-xs border border-emerald-400/40"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Email Card (Frosted Glass) */}
            <div className="bg-white/75 hover:bg-white/95 backdrop-blur-md rounded-3xl p-5 border border-white/80 hover:border-[#D4AF37]/60 transition-all shadow-sm">
              <div className="flex items-start space-x-3.5">
                <div className="w-10 h-10 rounded-2xl bg-blue-500/10 text-blue-700 flex items-center justify-center shrink-0 mt-0.5 border border-blue-300">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    📧 Official Email
                  </h4>
                  <a
                    href={`mailto:${STORE_CONTACT.email}`}
                    className="text-xs sm:text-sm font-bold text-[#001F3F] hover:text-[#D4AF37] transition-colors block mt-1 break-all"
                  >
                    {STORE_CONTACT.email}
                  </a>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    For bulk wholesale dealer inquiries and corporate fleet upgrades.
                  </p>
                </div>
              </div>
            </div>

            {/* Timings Card (Frosted Glass) */}
            <div className="bg-white/75 hover:bg-white/95 backdrop-blur-md rounded-3xl p-5 border border-white/80 hover:border-[#D4AF37]/60 transition-all shadow-sm">
              <div className="flex items-start space-x-3.5">
                <div className="w-10 h-10 rounded-2xl bg-purple-500/10 text-purple-700 flex items-center justify-center shrink-0 mt-0.5 border border-purple-300">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    🕒 Fitting Bay Timings
                  </h4>
                  <p className="text-xs font-bold text-[#001F3F] mt-1">
                    {STORE_CONTACT.workingHours}
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Open all 7 days with dedicated customer parking & fitting bays.
                  </p>
                </div>
              </div>
            </div>

          </div>

          {/* Interactive Google Map Preview & Directions (7 cols) */}
          <div className="lg:col-span-7 bg-[#001F3F]/90 backdrop-blur-xl rounded-3xl overflow-hidden shadow-2xl border border-[#D4AF37]/40 flex flex-col justify-between">
            {/* Map Header */}
            <div className="p-4 bg-[#001F3F] text-white flex items-center justify-between border-b border-white/10">
              <div className="flex items-center space-x-2">
                <Navigation className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-xs font-bold tracking-wide text-white">
                  🗺️ Google Maps Location & Live Directions
                </span>
              </div>
              <a
                href={STORE_CONTACT.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-[#D4AF37] hover:text-amber-300 font-semibold flex items-center"
              >
                <span>Open in Google Maps</span>
                <ExternalLink className="w-3.5 h-3.5 ml-1" />
              </a>
            </div>

            {/* Embedded Google Map */}
            <div className="relative aspect-16/10 w-full bg-slate-800">
              <iframe
                title="3A Auto Accessories Location"
                src={STORE_CONTACT.embedMapUrl}
                className="w-full h-full border-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>

            {/* Map Footnote Banner */}
            <div className="p-4 bg-[#001730] text-slate-300 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-t border-white/10">
              <span className="flex items-center text-[#D4AF37]">
                <ShieldCheck className="w-4 h-4 mr-1.5 shrink-0" />
                <span>On-site Installation & Free Beam Alignment Available</span>
              </span>
              <a
                href={STORE_CONTACT.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center text-xs font-bold text-[#001F3F] bg-[#D4AF37] hover:bg-amber-300 px-3.5 py-1.5 rounded-xl transition-colors shrink-0 shadow-md"
              >
                <Navigation className="w-3.5 h-3.5 mr-1" />
                <span>Get Driving Directions</span>
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
