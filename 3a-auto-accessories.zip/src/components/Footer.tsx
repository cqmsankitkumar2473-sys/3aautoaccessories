import React from 'react';
import { 
  Sparkles, 
  Phone, 
  Mail, 
  MapPin, 
  MessageSquare, 
  ShieldCheck, 
  Award, 
  ArrowUp,
  Heart,
  ChevronRight
} from 'lucide-react';
import { STORE_CONTACT, buildWhatsAppUrl, getGeneralInquiryMessage } from '../utils/whatsapp';
import { ProductCategory } from '../types';

interface FooterProps {
  onSelectCategory: (cat: ProductCategory) => void;
  onNavigate: (sectionId: string) => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectCategory,
  onNavigate,
  onOpenAdmin
}) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="main-footer" className="bg-[#001F3F] text-slate-300 border-t border-[#D4AF37]/30 text-xs relative overflow-hidden">
      {/* Background glow effects */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#D4AF37]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-blue-900/20 rounded-full blur-3xl pointer-events-none" />

      {/* Top Banner / Trust Bar */}
      <div className="border-b border-white/10 bg-[#001730]/60 backdrop-blur-md py-6 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-2 md:grid-cols-4 gap-4 text-center sm:text-left">
          <div className="flex items-center space-x-3 justify-center sm:justify-start">
            <ShieldCheck className="w-6 h-6 text-[#D4AF37] shrink-0" />
            <div>
              <p className="font-bold text-white text-xs sm:text-sm">Zero Wire-Cut Fitment</p>
              <p className="text-[11px] text-slate-300">100% Car Warranty Safe</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 justify-center sm:justify-start">
            <Award className="w-6 h-6 text-[#D4AF37] shrink-0" />
            <div>
              <p className="font-bold text-white text-xs sm:text-sm">2-Year Replacement</p>
              <p className="text-[11px] text-slate-300">Hassle-Free Direct Warranty</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 justify-center sm:justify-start">
            <Sparkles className="w-6 h-6 text-[#D4AF37] shrink-0" />
            <div>
              <p className="font-bold text-white text-xs sm:text-sm">100% Genuine Parts</p>
              <p className="text-[11px] text-slate-300">OEM & Certified Upgrades</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 justify-center sm:justify-start">
            <Phone className="w-6 h-6 text-emerald-400 shrink-0" />
            <div>
              <p className="font-bold text-white text-xs sm:text-sm">Personal Support</p>
              <p className="text-[11px] text-slate-300">Directly by Ankit Kumar</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8">
          
          {/* Brand Info (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-[#D4AF37]/50 shadow-md">
                <span className="text-[#D4AF37] font-serif font-extrabold text-lg">3A</span>
              </div>
              <div>
                <span className="text-lg font-bold font-serif text-white">3A Auto Accessories</span>
                <p className="text-[10px] text-[#D4AF37] uppercase tracking-widest font-semibold">By Ankit Kumar</p>
              </div>
            </div>

            <p className="text-slate-300 leading-relaxed text-xs">
              Your premier destination for high-intensity LED headlights, 3-color fog lamps, 24K gold temple flags, 64-color ambient lighting, custom Nappa seat covers, 7D mats, and bespoke modifications.
            </p>

            <div className="pt-2 flex items-center space-x-3">
              <a
                href={buildWhatsAppUrl(getGeneralInquiryMessage())}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3.5 py-2 rounded-xl flex items-center space-x-1.5 shadow-sm transition-all border border-emerald-400/40"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>WhatsApp Us</span>
              </a>
              <button
                onClick={onOpenAdmin}
                className="text-slate-400 hover:text-[#D4AF37] transition-colors text-[11px] underline"
              >
                Store Admin Panel
              </button>
            </div>
          </div>

          {/* Product Categories (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-sm font-bold font-serif text-white tracking-wide uppercase">
              Featured Categories
            </h4>
            <ul className="space-y-2 text-slate-300">
              <li>
                <button
                  onClick={() => onSelectCategory('led-headlights')}
                  className="hover:text-[#D4AF37] transition-colors flex items-center"
                >
                  <ChevronRight className="w-3 h-3 mr-1 text-[#D4AF37]" />
                  💡 LED Headlights & Fog Projectors
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('temple-flags')}
                  className="hover:text-[#D4AF37] transition-colors flex items-center"
                >
                  <ChevronRight className="w-3 h-3 mr-1 text-[#D4AF37]" />
                  🚩 24K Gold Temple Flags & Emblems
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('interior-accessories')}
                  className="hover:text-[#D4AF37] transition-colors flex items-center"
                >
                  <ChevronRight className="w-3 h-3 mr-1 text-[#D4AF37]" />
                  ✨ Symphony Ambient Lights & 2K Screens
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('interior-accessories')}
                  className="hover:text-[#D4AF37] transition-colors flex items-center"
                >
                  <ChevronRight className="w-3 h-3 mr-1 text-[#D4AF37]" />
                  💺 Nappa Seat Covers & 7D Mats
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('exterior-accessories')}
                  className="hover:text-[#D4AF37] transition-colors flex items-center"
                >
                  <ChevronRight className="w-3 h-3 mr-1 text-[#D4AF37]" />
                  🚘 Door Visors & Chrome Styling
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('modification-parts')}
                  className="hover:text-[#D4AF37] transition-colors flex items-center"
                >
                  <ChevronRight className="w-3 h-3 mr-1 text-[#D4AF37]" />
                  🔧 Valvetronic Exhausts & Grilles
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('car-care')}
                  className="hover:text-[#D4AF37] transition-colors flex items-center"
                >
                  <ChevronRight className="w-3 h-3 mr-1 text-[#D4AF37]" />
                  🧴 9H Ceramic Coating & Fragrances
                </button>
              </li>
            </ul>
          </div>

          {/* Quick Navigation (2 cols) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-sm font-bold font-serif text-white tracking-wide uppercase">
              Quick Links
            </h4>
            <ul className="space-y-2 text-slate-300">
              <li>
                <button onClick={() => onNavigate('hero-section')} className="hover:text-[#D4AF37] transition-colors">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('products-section')} className="hover:text-[#D4AF37] transition-colors">
                  All Products
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('packages-section')} className="hover:text-[#D4AF37] transition-colors">
                  Modification Combos
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('why-us-section')} className="hover:text-[#D4AF37] transition-colors">
                  Why 3A Accessories?
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('gallery-section')} className="hover:text-[#D4AF37] transition-colors">
                  Transformations
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('reviews-section')} className="hover:text-[#D4AF37] transition-colors">
                  Customer Reviews
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('inquiry-section')} className="hover:text-[#D4AF37] transition-colors">
                  Inquiry Form
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Details (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-sm font-bold font-serif text-white tracking-wide uppercase">
              Contact & Location
            </h4>
            <ul className="space-y-2.5 text-slate-300">
              <li className="flex items-start space-x-2">
                <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span>{STORE_CONTACT.address}, {STORE_CONTACT.cityState}</span>
              </li>
              <li className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <a href={`tel:${STORE_CONTACT.phone}`} className="hover:text-amber-300 font-semibold text-white">
                  {STORE_CONTACT.displayPhone}
                </a>
              </li>
              <li className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <a href={`mailto:${STORE_CONTACT.email}`} className="hover:text-amber-300 break-all">
                  {STORE_CONTACT.email}
                </a>
              </li>
              <li className="flex items-center space-x-2 text-emerald-400 font-medium">
                <MessageSquare className="w-4 h-4 shrink-0" />
                <span>WhatsApp: {STORE_CONTACT.name}</span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-400">
          <p>© {new Date().getFullYear()} 3A Auto Accessories. Owned & Curated by Ankit Kumar. All Rights Reserved.</p>
          <div className="flex items-center space-x-4">
            <span className="text-slate-300 flex items-center">
              Crafted with <Heart className="w-3.5 h-3.5 text-rose-400 mx-1 fill-rose-400" /> for Car Enthusiasts
            </span>
            <button
              onClick={scrollToTop}
              className="p-2 bg-white/10 hover:bg-[#D4AF37] hover:text-[#001F3F] text-slate-200 rounded-xl transition-colors border border-white/10"
              title="Back to top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
