import React from 'react';
import { 
  ShieldCheck, 
  Sparkles, 
  Wrench, 
  BadgePercent, 
  Headphones, 
  Award,
  CheckCircle,
  Clock,
  Car
} from 'lucide-react';

export const WhyChooseUs: React.FC = () => {
  const features = [
    {
      icon: <Award className="w-7 h-7 text-[#D4AF37]" />,
      title: '✔ Premium Quality Products',
      subtitle: 'Grade-A Automotive Hardware',
      desc: 'We strictly stock OEM-spec and certified aftermarket accessories. From German CSP LED chips to 24K gold plated brass temple flags, zero compromises on build quality.'
    },
    {
      icon: <Sparkles className="w-7 h-7 text-indigo-500" />,
      title: '✔ Latest Car Accessories',
      subtitle: '2026 Trending Innovations',
      desc: 'Stay ahead of the curve with cutting-edge upgrades: 64-color dynamic chasing ambient lights, 2K QLED wireless CarPlay Android head units, and solar fragrance spinners.'
    },
    {
      icon: <Wrench className="w-7 h-7 text-emerald-500" />,
      title: '✔ Professional Installation',
      subtitle: 'Zero Wire-Cut Guarantee',
      desc: 'Our trained automotive technicians use factory fuse taps and coupler-to-coupler harness connectors. Your vehicle insurance and factory warranty remain 100% intact.'
    },
    {
      icon: <BadgePercent className="w-7 h-7 text-rose-500" />,
      title: '✔ Affordable Prices',
      subtitle: 'Direct Distributor Value',
      desc: 'Transparent pricing with no middlemen markups. Enjoy bundled package discounts, free fitment consultation, and guaranteed maximum value for every rupee spent.'
    },
    {
      icon: <Headphones className="w-7 h-7 text-cyan-500" />,
      title: '✔ Trusted Customer Support',
      subtitle: 'Personal Support by Ankit Kumar',
      desc: 'Get direct advice from owner Ankit Kumar for car model fitment, troubleshooting, and hassle-free warranty claim replacements whenever you need assistance.'
    }
  ];

  return (
    <section id="why-us-section" className="py-16 sm:py-24 bg-white/60 backdrop-blur-md border-b border-slate-200/60 relative">
      {/* Background Glow */}
      <div className="absolute top-1/3 right-10 w-96 h-96 bg-amber-100/25 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center space-x-2 bg-white/80 border border-[#D4AF37]/50 text-[#001F3F] rounded-full px-3.5 py-1 text-xs font-semibold uppercase tracking-wider mb-3 backdrop-blur-md shadow-xs">
            <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>The 3A Excellence Standard</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold font-serif text-[#001F3F] tracking-tight">
            Why Choose 3A Auto Accessories?
          </h2>
          <p className="text-slate-600 text-sm sm:text-base mt-2">
            Trusted by over 50,000 car owners across India for genuine products, craftsmanship, and reliable after-sales support.
          </p>
        </div>

        {/* Feature Cards Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feat, index) => (
            <div 
              key={index}
              className="bg-white/70 hover:bg-white/95 backdrop-blur-md rounded-3xl p-7 border border-white/80 hover:border-[#D4AF37]/70 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                <div className="w-14 h-14 rounded-2xl bg-white/90 border border-slate-200/80 group-hover:border-[#D4AF37]/50 shadow-xs flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300 backdrop-blur-md">
                  {feat.icon}
                </div>
                <h3 className="text-lg font-bold text-[#001F3F] group-hover:text-[#D4AF37] transition-colors font-serif">
                  {feat.title}
                </h3>
                <p className="text-xs font-semibold text-amber-700 mt-0.5 uppercase tracking-wide">
                  {feat.subtitle}
                </p>
                <p className="text-xs sm:text-sm text-slate-600 mt-3 leading-relaxed">
                  {feat.desc}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-200/60 flex items-center text-xs font-semibold text-slate-700 group-hover:text-[#001F3F]">
                <CheckCircle className="w-4 h-4 text-emerald-500 mr-1.5" />
                <span>100% Tested & Verified</span>
              </div>
            </div>
          ))}

          {/* Quick Stats Highlight Card (Frosted Navy Glass) */}
          <div className="bg-gradient-to-br from-[#001F3F]/95 to-[#0A3663]/90 backdrop-blur-xl text-white rounded-3xl p-7 shadow-2xl border border-[#D4AF37]/40 flex flex-col justify-between relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#D4AF37]/10 rounded-full blur-2xl pointer-events-none" />

            <div>
              <div className="inline-block bg-[#D4AF37] text-[#001F3F] text-xs font-extrabold px-3.5 py-1 rounded-full mb-4 shadow-sm">
                Our Track Record
              </div>
              <h3 className="text-2xl font-bold font-serif text-[#D4AF37]">
                10+ Years of Crafting Dream Cars
              </h3>
              <p className="text-xs text-slate-200 mt-2 leading-relaxed">
                Supervised directly by Ankit Kumar, our workshop has transformed hundreds of luxury SUVs, sedans, and off-road beasts.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 mt-6 pt-4 border-t border-white/15">
              <div>
                <p className="text-2xl font-extrabold text-white">50,000+</p>
                <p className="text-[11px] text-slate-300">Happy Drivers</p>
              </div>
              <div>
                <p className="text-2xl font-extrabold text-[#D4AF37]">100%</p>
                <p className="text-[11px] text-slate-300">Coupler Fitment</p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
