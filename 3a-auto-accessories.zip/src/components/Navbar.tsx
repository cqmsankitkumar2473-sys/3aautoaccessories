import React, { useState, useEffect } from 'react';
import { 
  Phone, 
  MessageSquare, 
  ShoppingBag, 
  Search, 
  Menu, 
  X, 
  ShieldCheck, 
  Wrench, 
  Sparkles,
  MapPin,
  Lock
} from 'lucide-react';
import { STORE_CONTACT, buildWhatsAppUrl, getGeneralInquiryMessage } from '../utils/whatsapp';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenAdmin: () => void;
  onSearchClick: () => void;
  onNavigate: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  cartCount,
  onOpenCart,
  onOpenAdmin,
  onSearchClick,
  onNavigate
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (sectionId: string) => {
    onNavigate(sectionId);
    setMobileMenuOpen(false);
  };

  return (
    <>
      {/* Top Announcement Bar */}
      <div id="top-announcement-bar" className="bg-[#001F3F]/95 backdrop-blur-md text-slate-200 text-xs border-b border-[#D4AF37]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2 flex flex-wrap justify-between items-center gap-2">
          <div className="flex items-center space-x-4">
            <span className="flex items-center text-[#D4AF37] font-medium tracking-wide">
              <Sparkles className="w-3.5 h-3.5 mr-1.5 animate-pulse text-[#D4AF37]" />
              Festive Car Upgrade Offer: Up to 35% OFF on LED Projectors & Ambient Kits
            </span>
            <span className="hidden md:inline-flex items-center text-slate-300">
              <ShieldCheck className="w-3.5 h-3.5 mr-1 text-emerald-400" />
              Zero Wire-Cut 100% Plug & Play Warranty
            </span>
          </div>

          <div className="flex items-center space-x-5 text-xs">
            <a 
              id="top-bar-phone"
              href={`tel:${STORE_CONTACT.phone}`} 
              className="flex items-center hover:text-[#D4AF37] transition-colors"
            >
              <Phone className="w-3 h-3 mr-1 text-[#D4AF37]" />
              <span>Call: {STORE_CONTACT.displayPhone}</span>
            </a>
            <span className="hidden sm:inline text-slate-600">|</span>
            <div className="hidden sm:flex items-center text-slate-300">
              <MapPin className="w-3 h-3 mr-1 text-[#D4AF37]" />
              <span>Delhi NCR Auto Hub</span>
            </div>
            <button
              id="top-bar-admin-btn"
              onClick={onOpenAdmin}
              className="text-slate-400 hover:text-[#D4AF37] flex items-center transition-colors text-[11px] font-medium"
              title="Store Management"
            >
              <Lock className="w-3 h-3 mr-1" />
              Admin
            </button>
          </div>
        </div>
      </div>

      {/* Main Sticky Header */}
      <header 
        id="main-navigation-header"
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled 
            ? 'bg-white/80 backdrop-blur-xl shadow-lg shadow-slate-900/5 border-b border-white/60 py-3' 
            : 'bg-white/70 backdrop-blur-lg border-b border-slate-200/60 py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          
          {/* Logo & Brand Identity */}
          <div 
            id="brand-logo-container"
            onClick={() => handleNavClick('hero-section')}
            className="flex items-center space-x-3 cursor-pointer group"
          >
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#001F3F] to-[#0A3663] flex items-center justify-center shadow-md shadow-slate-900/10 group-hover:scale-105 transition-transform duration-300 border border-[#D4AF37]/50 backdrop-blur-md">
              <span className="text-[#D4AF37] font-extrabold text-xl font-serif tracking-tight">3A</span>
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="text-xl sm:text-2xl font-bold tracking-tight text-[#001F3F] font-serif">
                  3A Auto
                </span>
                <span className="text-[#D4AF37] font-bold text-xl sm:text-2xl font-serif">
                  Accessories
                </span>
              </div>
              <p className="text-[11px] font-medium text-slate-500 tracking-wider uppercase flex items-center">
                <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] mr-1.5"></span>
                By Ankit Kumar
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav id="desktop-nav-links" className="hidden lg:flex items-center space-x-7">
            <button
              id="nav-home"
              onClick={() => handleNavClick('hero-section')}
              className="text-sm font-semibold text-slate-700 hover:text-[#001F3F] hover:text-[#D4AF37] transition-colors"
            >
              Home
            </button>
            <button
              id="nav-categories"
              onClick={() => handleNavClick('categories-section')}
              className="text-sm font-semibold text-slate-700 hover:text-[#D4AF37] transition-colors"
            >
              Categories
            </button>
            <button
              id="nav-products"
              onClick={() => handleNavClick('products-section')}
              className="text-sm font-semibold text-slate-700 hover:text-[#D4AF37] transition-colors"
            >
              All Products
            </button>
            <button
              id="nav-packages"
              onClick={() => handleNavClick('packages-section')}
              className="text-sm font-semibold text-slate-700 hover:text-[#D4AF37] transition-colors flex items-center"
            >
              <Wrench className="w-3.5 h-3.5 mr-1 text-[#D4AF37]" />
              Modification Packs
            </button>
            <button
              id="nav-why-us"
              onClick={() => handleNavClick('why-us-section')}
              className="text-sm font-semibold text-slate-700 hover:text-[#D4AF37] transition-colors"
            >
              Why 3A?
            </button>
            <button
              id="nav-gallery"
              onClick={() => handleNavClick('gallery-section')}
              className="text-sm font-semibold text-slate-700 hover:text-[#D4AF37] transition-colors"
            >
              Transformations
            </button>
            <button
              id="nav-reviews"
              onClick={() => handleNavClick('reviews-section')}
              className="text-sm font-semibold text-slate-700 hover:text-[#D4AF37] transition-colors"
            >
              Reviews
            </button>
            <button
              id="nav-contact"
              onClick={() => handleNavClick('contact-section')}
              className="text-sm font-semibold text-slate-700 hover:text-[#D4AF37] transition-colors"
            >
              Contact
            </button>
          </nav>

          {/* Action CTAs: Search, Cart & WhatsApp */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Search Trigger */}
            <button
              id="nav-search-button"
              onClick={onSearchClick}
              className="p-2.5 rounded-full text-slate-600 hover:text-[#001F3F] hover:bg-white/80 backdrop-blur-md transition-colors relative border border-transparent hover:border-slate-200/60"
              aria-label="Search car accessories"
              title="Search accessories"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Quote / Wishlist Basket */}
            <button
              id="nav-cart-button"
              onClick={onOpenCart}
              className="p-2.5 rounded-full text-slate-700 hover:text-[#001F3F] hover:bg-white/80 backdrop-blur-md transition-colors relative border border-transparent hover:border-slate-200/60"
              aria-label="View Enquiry Basket"
              title="Enquiry Basket"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#D4AF37] text-[#001F3F] text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center shadow-md">
                  {cartCount}
                </span>
              )}
            </button>

            {/* WhatsApp Us CTA Button */}
            <a
              id="nav-whatsapp-cta"
              href={buildWhatsAppUrl(getGeneralInquiryMessage())}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center space-x-2 bg-[#001F3F] hover:bg-[#0A3663] text-white px-4 py-2.5 rounded-xl font-semibold text-sm transition-all duration-200 shadow-md hover:shadow-lg border border-[#D4AF37]/40 group backdrop-blur-md"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <MessageSquare className="w-4 h-4 text-emerald-400 fill-emerald-400/20 group-hover:scale-110 transition-transform" />
              <span>WhatsApp Us</span>
            </a>

            {/* Mobile Hamburger Button */}
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2.5 rounded-xl text-slate-700 hover:bg-white/80 backdrop-blur-md focus:outline-none border border-transparent hover:border-slate-200/60"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div id="mobile-dropdown-menu" className="lg:hidden bg-white/95 backdrop-blur-xl border-b border-slate-200 px-4 pt-3 pb-6 space-y-2 shadow-2xl animate-in fade-in slide-in-from-top-2 duration-200">
            <button
              onClick={() => handleNavClick('hero-section')}
              className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-semibold text-slate-800 hover:bg-slate-50 hover:text-[#D4AF37]"
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('categories-section')}
              className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-semibold text-slate-800 hover:bg-slate-50 hover:text-[#D4AF37]"
            >
              Featured Categories
            </button>
            <button
              onClick={() => handleNavClick('products-section')}
              className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-semibold text-slate-800 hover:bg-slate-50 hover:text-[#D4AF37]"
            >
              All Products Catalog
            </button>
            <button
              onClick={() => handleNavClick('packages-section')}
              className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-semibold text-slate-800 hover:bg-slate-50 hover:text-[#D4AF37] flex items-center justify-between"
            >
              <span>Custom Modification Packs</span>
              <span className="text-[10px] bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded-full border border-[#D4AF37]/30">Save Big</span>
            </button>
            <button
              onClick={() => handleNavClick('why-us-section')}
              className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-semibold text-slate-800 hover:bg-slate-50 hover:text-[#D4AF37]"
            >
              Why Choose 3A?
            </button>
            <button
              onClick={() => handleNavClick('gallery-section')}
              className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-semibold text-slate-800 hover:bg-slate-50 hover:text-[#D4AF37]"
            >
              Customer Car Transformations
            </button>
            <button
              onClick={() => handleNavClick('reviews-section')}
              className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-semibold text-slate-800 hover:bg-slate-50 hover:text-[#D4AF37]"
            >
              Customer Reviews (5.0 ⭐)
            </button>
            <button
              onClick={() => handleNavClick('contact-section')}
              className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-semibold text-slate-800 hover:bg-slate-50 hover:text-[#D4AF37]"
            >
              Contact & Store Location
            </button>

            <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
              <a
                href={buildWhatsAppUrl(getGeneralInquiryMessage())}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center space-x-2 bg-emerald-600 text-white py-3 rounded-xl font-semibold text-sm shadow-md"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Chat on WhatsApp (Ankit Kumar)</span>
              </a>
              <a
                href={`tel:${STORE_CONTACT.phone}`}
                className="w-full flex items-center justify-center space-x-2 bg-[#001F3F] text-[#D4AF37] py-3 rounded-xl font-semibold text-sm border border-[#D4AF37]/30"
              >
                <Phone className="w-4 h-4" />
                <span>Call Store: {STORE_CONTACT.displayPhone}</span>
              </a>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
