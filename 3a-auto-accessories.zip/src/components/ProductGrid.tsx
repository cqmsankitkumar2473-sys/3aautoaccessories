import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  SlidersHorizontal, 
  Car, 
  Sparkles, 
  RotateCcw,
  Tag
} from 'lucide-react';
import { Product, ProductCategory } from '../types';
import { ProductCard } from './ProductCard';

interface ProductGridProps {
  products: Product[];
  selectedCategory: ProductCategory;
  onSelectCategory: (category: ProductCategory) => void;
  onOpenModal: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  cartProductIds: Set<string>;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

const CATEGORY_TABS: { id: ProductCategory; label: string }[] = [
  { id: 'all', label: 'All Items' },
  { id: 'led-headlights', label: '💡 LED Headlights' },
  { id: 'fog-lamps', label: '🌫️ Fog Lamps' },
  { id: 'temple-flags', label: '🚩 Temple Flags' },
  { id: 'interior-accessories', label: '✨ Interior' },
  { id: 'exterior-accessories', label: '🚘 Exterior' },
  { id: 'modification-parts', label: '🔧 Modification' },
  { id: 'car-care', label: '🧴 Car Care' },
];

const CAR_FILTER_OPTIONS = [
  'All Vehicles',
  'Universal Fit',
  'Mahindra Thar',
  'Mahindra Scorpio-N',
  'Hyundai Creta',
  'Toyota Fortuner',
  'Maruti Swift / Brezza',
  'Tata Harrier / Safari / Nexon',
  'Kia Seltos / Sonet'
];

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  selectedCategory,
  onSelectCategory,
  onOpenModal,
  onAddToCart,
  cartProductIds,
  searchQuery,
  setSearchQuery,
}) => {
  const [selectedCarFilter, setSelectedCarFilter] = useState('All Vehicles');
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'rating'>('featured');
  const [inStockOnly, setInStockOnly] = useState(false);

  // Filtered & Sorted Products
  const filteredProducts = useMemo(() => {
    return products.filter((prod) => {
      // Category filter
      if (selectedCategory !== 'all' && prod.category !== selectedCategory) {
        return false;
      }

      // Stock filter
      if (inStockOnly && !prod.inStock) {
        return false;
      }

      // Search query (name, category, description, specs)
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = prod.name.toLowerCase().includes(q);
        const matchesCat = prod.categoryName.toLowerCase().includes(q);
        const matchesDesc = prod.description.toLowerCase().includes(q);
        const matchesShort = prod.shortDesc.toLowerCase().includes(q);
        const matchesCar = prod.compatibleCars.some((c) => c.toLowerCase().includes(q));
        if (!matchesName && !matchesCat && !matchesDesc && !matchesShort && !matchesCar) {
          return false;
        }
      }

      // Car filter
      if (selectedCarFilter !== 'All Vehicles') {
        if (selectedCarFilter === 'Universal Fit') {
          const isUni = prod.compatibleCars.some((c) => c.toLowerCase().includes('universal'));
          if (!isUni) return false;
        } else {
          const target = selectedCarFilter.toLowerCase();
          const matches = prod.compatibleCars.some((c) => {
            const low = c.toLowerCase();
            return low.includes('universal') || 
              (target.includes('thar') && low.includes('thar')) ||
              (target.includes('scorpio') && low.includes('scorpio')) ||
              (target.includes('creta') && low.includes('creta')) ||
              (target.includes('fortuner') && low.includes('fortuner')) ||
              (target.includes('swift') && (low.includes('swift') || low.includes('brezza') || low.includes('baleno'))) ||
              (target.includes('harrier') && (low.includes('harrier') || low.includes('nexon') || low.includes('safari'))) ||
              (target.includes('seltos') && (low.includes('seltos') || low.includes('sonet')));
          });
          if (!matches) return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      // Default: featured first
      if (a.featured && !b.featured) return -1;
      if (!a.featured && b.featured) return 1;
      return 0;
    });
  }, [products, selectedCategory, searchQuery, selectedCarFilter, inStockOnly, sortBy]);

  const resetFilters = () => {
    onSelectCategory('all');
    setSearchQuery('');
    setSelectedCarFilter('All Vehicles');
    setInStockOnly(false);
    setSortBy('featured');
  };

  return (
    <section id="products-section" className="py-16 sm:py-20 bg-slate-100/40 backdrop-blur-sm border-b border-slate-200/60 relative">
      {/* Frosted ambient background elements */}
      <div className="absolute top-40 left-1/4 w-80 h-80 bg-amber-100/30 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-20 right-1/4 w-80 h-80 bg-blue-100/30 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Title Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center space-x-1.5 bg-white/80 text-[#001F3F] border border-[#D4AF37]/50 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-2 backdrop-blur-md shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Master Catalog</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold font-serif text-[#001F3F] tracking-tight">
            Our Premium Products
          </h2>
          <p className="text-slate-600 text-sm sm:text-base mt-2">
            Explore authentic LED lighting, interior luxury, temple flags, and custom modification hardware with verified car fitment.
          </p>
        </div>

        {/* Search & Filter Controls Bar (Frosted Glass) */}
        <div className="bg-white/75 backdrop-blur-xl p-4 sm:p-5 rounded-3xl border border-white/80 shadow-lg shadow-slate-900/5 mb-8 space-y-4">
          
          {/* Top Search & Car Filter Row */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            
            {/* Search Input Box */}
            <div className="md:col-span-6 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                id="catalog-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search LED headlights, 7D mats, temple flags, exhausts, perfumes..."
                className="w-full pl-10 pr-4 py-2.5 bg-white/70 hover:bg-white focus:bg-white text-slate-900 placeholder:text-slate-400 text-xs sm:text-sm rounded-xl border border-slate-200/80 focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20 focus:outline-none transition-all backdrop-blur-md"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-slate-400 hover:text-slate-700"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Car Compatibility Filter */}
            <div className="md:col-span-3 relative">
              <Car className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <select
                id="catalog-car-filter"
                value={selectedCarFilter}
                onChange={(e) => setSelectedCarFilter(e.target.value)}
                className="w-full pl-10 pr-8 py-2.5 bg-white/70 hover:bg-white focus:bg-white text-slate-900 text-xs sm:text-sm rounded-xl border border-slate-200/80 focus:border-[#D4AF37] focus:outline-none transition-all appearance-none cursor-pointer backdrop-blur-md"
              >
                {CAR_FILTER_OPTIONS.map((car) => (
                  <option key={car} value={car}>{car}</option>
                ))}
              </select>
              <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs">▼</div>
            </div>

            {/* Sort Options */}
            <div className="md:col-span-3 relative">
              <SlidersHorizontal className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <select
                id="catalog-sort-select"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full pl-10 pr-8 py-2.5 bg-white/70 hover:bg-white focus:bg-white text-slate-900 text-xs sm:text-sm rounded-xl border border-slate-200/80 focus:border-[#D4AF37] focus:outline-none transition-all appearance-none cursor-pointer backdrop-blur-md"
              >
                <option value="featured">Featured First</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
              </select>
              <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs">▼</div>
            </div>

          </div>

          {/* Category Tabs Pill Bar */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-1 scrollbar-none">
            {CATEGORY_TABS.map((tab) => (
              <button
                key={tab.id}
                id={`filter-tab-${tab.id}`}
                onClick={() => onSelectCategory(tab.id)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all duration-200 backdrop-blur-md ${
                  selectedCategory === tab.id
                    ? 'bg-[#001F3F] text-[#D4AF37] shadow-md border border-[#D4AF37]/50'
                    : 'bg-white/80 text-slate-700 hover:bg-white hover:text-slate-900 border border-slate-200/60'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Active Summary & Quick Reset */}
          <div className="flex items-center justify-between text-xs text-slate-500 pt-1 border-t border-slate-100">
            <div>
              Showing <span className="font-bold text-slate-900">{filteredProducts.length}</span> products
              {selectedCategory !== 'all' && (
                <span className="ml-1 text-[#D4AF37] font-bold">in {selectedCategory.replace('-', ' ')}</span>
              )}
              {selectedCarFilter !== 'All Vehicles' && (
                <span className="ml-1 text-[#001F3F] font-bold">for {selectedCarFilter}</span>
              )}
            </div>

            {(selectedCategory !== 'all' || searchQuery || selectedCarFilter !== 'All Vehicles') && (
              <button
                onClick={resetFilters}
                className="flex items-center text-rose-600 hover:text-rose-700 font-semibold"
              >
                <RotateCcw className="w-3 h-3 mr-1" />
                Reset Filters
              </button>
            )}
          </div>

        </div>

        {/* Products Grid Output */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onOpenModal={onOpenModal}
                onAddToCart={onAddToCart}
                isInCart={cartProductIds.has(product.id)}
              />
            ))}
          </div>
        ) : (
          /* Empty Search State */
          <div className="text-center py-16 bg-white/80 backdrop-blur-md rounded-3xl border border-slate-200/80 p-8 shadow-md max-w-lg mx-auto">
            <div className="w-14 h-14 bg-amber-50 rounded-2xl flex items-center justify-center mx-auto text-[#D4AF37] mb-4 border border-amber-200/80">
              <Search className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-[#001F3F] font-serif">No Accessories Found</h3>
            <p className="text-slate-500 text-xs sm:text-sm mt-1">
              We couldn't find items matching "{searchQuery}". Contact Ankit Kumar directly on WhatsApp for custom car part sourcing.
            </p>
            <button
              onClick={resetFilters}
              className="mt-5 inline-flex items-center px-4 py-2 bg-[#001F3F] text-[#D4AF37] text-xs font-bold rounded-xl shadow-md hover:bg-[#0A3663] border border-[#D4AF37]/40"
            >
              <RotateCcw className="w-3.5 h-3.5 mr-1.5" />
              Reset All Filters
            </button>
          </div>
        )}

      </div>
    </section>
  );
};
