export type ProductCategory = 
  | 'all'
  | 'led-headlights'
  | 'fog-lamps'
  | 'temple-flags'
  | 'interior-accessories'
  | 'exterior-accessories'
  | 'modification-parts'
  | 'car-care';

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  categoryName: string;
  price: number;
  originalPrice: number;
  rating: number;
  reviewsCount: number;
  image: string;
  gallery: string[];
  inStock: boolean;
  featured: boolean;
  badge?: string;
  description: string;
  shortDesc: string;
  specs: Record<string, string>;
  compatibleCars: string[];
  installationTime: string;
  warranty: string;
  isBestSeller?: boolean;
}

export interface CategoryInfo {
  id: ProductCategory;
  name: string;
  icon: string;
  count: number;
  description: string;
  image: string;
  tagline: string;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  date: string;
  comment: string;
  carModel: string;
  productPurchased: string;
  verified: boolean;
  location: string;
  avatar?: string;
}

export interface InquiryItem {
  id: string;
  customerName: string;
  phoneNumber: string;
  email?: string;
  carModel: string;
  selectedCategory: string;
  message: string;
  preferredDate?: string;
  status: 'new' | 'contacted' | 'completed';
  createdAt: string;
  itemsInterested?: string[];
}

export interface CartItem {
  product: Product;
  quantity: number;
  carModel?: string;
}

export interface ModificationPackage {
  id: string;
  name: string;
  tier: 'Essential' | 'Pro Styling' | 'VIP Beast Edition';
  targetSegment: string;
  originalTotal: number;
  packagePrice: number;
  itemsIncluded: string[];
  estimatedTime: string;
  badge: string;
  image: string;
}
