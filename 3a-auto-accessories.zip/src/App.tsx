import React, { useState, useEffect, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { CategoriesSection } from './components/CategoriesSection';
import { ProductGrid } from './components/ProductGrid';
import { WhyChooseUs } from './components/WhyChooseUs';
import { CustomPackagesSection } from './components/CustomPackagesSection';
import { GallerySection } from './components/GallerySection';
import { ReviewsSection } from './components/ReviewsSection';
import { InquirySection } from './components/InquirySection';
import { ContactAndMap } from './components/ContactAndMap';
import { Footer } from './components/Footer';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { AdminModal } from './components/AdminModal';
import { MobileBottomNav } from './components/MobileBottomNav';

import { INITIAL_PRODUCTS } from './data/products';
import { INITIAL_REVIEWS } from './data/reviews';
import { Product, ProductCategory, CartItem, InquiryItem, Review } from './types';
import { Check, ShoppingBag, X } from 'lucide-react';

export default function App() {
  // Products state (persisted in localStorage)
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('3a_products');
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch (_) {
      return INITIAL_PRODUCTS;
    }
  });

  // Reviews state (persisted in localStorage)
  const [reviews, setReviews] = useState<Review[]>(() => {
    try {
      const saved = localStorage.getItem('3a_reviews');
      return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
    } catch (_) {
      return INITIAL_REVIEWS;
    }
  });

  // Inquiries state
  const [inquiries, setInquiries] = useState<InquiryItem[]>(() => {
    try {
      const saved = localStorage.getItem('3a_inquiries');
      return saved ? JSON.parse(saved) : [];
    } catch (_) {
      return [];
    }
  });

  // Cart / Quotation Basket
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('3a_cart');
      return saved ? JSON.parse(saved) : [];
    } catch (_) {
      return [];
    }
  });

  // Filter & Search states
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals & Drawers
  const [activeProductModal, setActiveProductModal] = useState<Product | null>(null);
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);
  const [adminModalOpen, setAdminModalOpen] = useState(false);

  // Toast Notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('3a_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('3a_reviews', JSON.stringify(reviews));
  }, [reviews]);

  useEffect(() => {
    localStorage.setItem('3a_inquiries', JSON.stringify(inquiries));
  }, [inquiries]);

  useEffect(() => {
    localStorage.setItem('3a_cart', JSON.stringify(cartItems));
  }, [cartItems]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectCategory = (cat: ProductCategory) => {
    setSelectedCategory(cat);
    scrollToSection('products-section');
  };

  const handleAddToCart = (product: Product, carModel?: string) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1, carModel: carModel || item.carModel }
            : item
        );
      }
      return [...prev, { product, quantity: 1, carModel }];
    });
    showToast(`Added "${product.name}" to Quotation Wishlist!`);
  };

  const handleUpdateCartQuantity = (productId: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Admin Handlers
  const handleAddProduct = (newProduct: Product) => {
    setProducts((prev) => [newProduct, ...prev]);
    showToast(`Published "${newProduct.name}" to store catalog!`);
  };

  const handleUpdateProduct = (updatedProduct: Product) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === updatedProduct.id ? updatedProduct : p))
    );
    showToast(`Updated product "${updatedProduct.name}"`);
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    showToast('Product removed from catalog');
  };

  const handleResetProducts = () => {
    setProducts(INITIAL_PRODUCTS);
    localStorage.removeItem('3a_products');
    showToast('Reset product catalog to default inventory');
  };

  const handleSaveInquiry = (inquiry: InquiryItem) => {
    setInquiries((prev) => [inquiry, ...prev]);
    showToast('Inquiry recorded! Connecting to WhatsApp...');
  };

  const handleUpdateInquiryStatus = (
    inquiryId: string,
    status: 'new' | 'contacted' | 'completed'
  ) => {
    setInquiries((prev) =>
      prev.map((inq) => (inq.id === inquiryId ? { ...inq, status } : inq))
    );
  };

  const handleAddReview = (review: Review) => {
    setReviews((prev) => [review, ...prev]);
    showToast('Thank you! Your 5-star review has been published.');
  };

  const handleDeleteReview = (reviewId: string) => {
    setReviews((prev) => prev.filter((r) => r.id !== reviewId));
  };

  const cartProductIds = useMemo(() => {
    return new Set(cartItems.map((item) => item.product.id));
  }, [cartItems]);

  const totalCartCount = useMemo(() => {
    return cartItems.reduce((acc, item) => acc + item.quantity, 0);
  }, [cartItems]);

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] text-slate-800 font-sans pb-16 lg:pb-0">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 bg-[#001F3F]/90 backdrop-blur-xl text-[#D4AF37] border border-[#D4AF37]/50 px-4 py-3 rounded-2xl shadow-2xl flex items-center space-x-2 text-xs font-bold animate-in slide-in-from-top-4 duration-200">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="text-white">{toastMessage}</span>
          <button
            onClick={() => setToastMessage(null)}
            className="text-slate-300 hover:text-white ml-2"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Top Navigation */}
      <Navbar
        cartCount={totalCartCount}
        onOpenCart={() => setCartDrawerOpen(true)}
        onOpenAdmin={() => setAdminModalOpen(true)}
        onSearchClick={() => {
          scrollToSection('products-section');
          const searchInput = document.getElementById('catalog-search-input');
          if (searchInput) searchInput.focus();
        }}
        onNavigate={scrollToSection}
      />

      <main className="flex-1">
        {/* 1. Hero Section */}
        <Hero
          onExploreProducts={() => scrollToSection('products-section')}
          onExplorePackages={() => scrollToSection('packages-section')}
        />

        {/* 2. Featured Categories */}
        <CategoriesSection onSelectCategory={handleSelectCategory} />

        {/* 3. Master Product Catalog with Search & Multi-Filters */}
        <ProductGrid
          products={products}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          onOpenModal={(prod) => setActiveProductModal(prod)}
          onAddToCart={handleAddToCart}
          cartProductIds={cartProductIds}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
        />

        {/* 4. Why Choose 3A Auto Accessories */}
        <WhyChooseUs />

        {/* 5. Custom Modification Packages */}
        <CustomPackagesSection />

        {/* 6. Customer Car Transformations & Gallery with HD Zoom */}
        <GallerySection />

        {/* 7. Customer Reviews & Ratings (5.0 ⭐) */}
        <ReviewsSection reviews={reviews} onAddReview={handleAddReview} />

        {/* 8. Online Fitment & Inquiry Form */}
        <InquirySection onSaveInquiry={handleSaveInquiry} />

        {/* 9. Contact Info & Google Maps Embed */}
        <ContactAndMap />
      </main>

      {/* Main Footer */}
      <Footer
        onSelectCategory={handleSelectCategory}
        onNavigate={scrollToSection}
        onOpenAdmin={() => setAdminModalOpen(true)}
      />

      {/* Modals & Drawers */}
      <ProductModal
        product={activeProductModal}
        onClose={() => setActiveProductModal(null)}
        onAddToCart={handleAddToCart}
        isInCart={activeProductModal ? cartProductIds.has(activeProductModal.id) : false}
      />

      <CartDrawer
        isOpen={cartDrawerOpen}
        onClose={() => setCartDrawerOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveFromCart}
        onClearCart={handleClearCart}
        onExploreProducts={() => {
          setCartDrawerOpen(false);
          scrollToSection('products-section');
        }}
      />

      <AdminModal
        isOpen={adminModalOpen}
        onClose={() => setAdminModalOpen(false)}
        products={products}
        onAddProduct={handleAddProduct}
        onUpdateProduct={handleUpdateProduct}
        onDeleteProduct={handleDeleteProduct}
        onResetProducts={handleResetProducts}
        inquiries={inquiries}
        onUpdateInquiryStatus={handleUpdateInquiryStatus}
        reviews={reviews}
        onDeleteReview={handleDeleteReview}
      />

      {/* Mobile Sticky Action Bar */}
      <MobileBottomNav
        cartCount={totalCartCount}
        onOpenCart={() => setCartDrawerOpen(true)}
        onNavigate={scrollToSection}
      />

    </div>
  );
}
