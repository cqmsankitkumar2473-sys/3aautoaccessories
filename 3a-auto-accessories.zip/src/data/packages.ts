import { ModificationPackage } from '../types';

export const MODIFICATION_PACKAGES: ModificationPackage[] = [
  {
    id: 'pkg-lighting-beast',
    name: 'Ultimate Night Rider Lighting Upgrade',
    tier: 'Essential',
    targetSegment: 'All SUVs & Sedans (Thar, Creta, Brezza, Swift, Fortuner)',
    originalTotal: 18999,
    packagePrice: 14499,
    itemsIncluded: [
      'AlphaBeam 180W Bi-LED Projector Headlights (6000K)',
      'ThunderLite 3-Color Switchable Bi-LED Fog Projectors',
      'Underbody Glow Ambient DRL Sync Lighting',
      'Free Zero-Wire-Cut Fuse Tap Installation Kit'
    ],
    estimatedTime: '2.5 Hours',
    badge: 'Popular Combo (Save ₹4,500)',
    image: 'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'pkg-vip-cabin',
    name: 'Maybach VIP Cabin Lounge Package',
    tier: 'Pro Styling',
    targetSegment: 'Luxury Interior Overhaul for any Hatchback / SUV',
    originalTotal: 34999,
    packagePrice: 26999,
    itemsIncluded: [
      'AuraPro 10.1" 2K QLED 8GB+128GB Android CarPlay System',
      'Symphony 64-Color Chasing Fiber Optic Ambient Lighting (18-in-1)',
      'Royal Nappa Diamond Laser-Cut Memory Foam Seat Covers',
      '7D Imperial Waterproof Double-Layer Anti-Skid Floor Mats'
    ],
    estimatedTime: '4.5 Hours',
    badge: 'Best Value (Save ₹8,000)',
    image: 'https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'pkg-thar-beast-master',
    name: '3A Signature Off-Road & Showroom Beast Edition',
    tier: 'VIP Beast Edition',
    targetSegment: 'Mahindra Thar / Scorpio-N / Fortuner / Jimny',
    originalTotal: 58999,
    packagePrice: 44999,
    itemsIncluded: [
      'AlphaBeam 180W Matrix Bi-LED + Raptor Honeycomb Front Grille',
      'Valvetronic Remote Dual Sport Exhaust with Carbon Tips',
      'Full 18-in-1 Symphony Light + 2K QLED 360 Head Unit',
      '3A Pro-Shield 9H Nano Ceramic 3-Year Paint Protection Coating',
      '24K Gold Sacred Temple Dashboard Flag Base with Hanuman Ji Idol'
    ],
    estimatedTime: 'Full Day Master Fitment',
    badge: 'Ultimate Transformation (Save ₹14,000)',
    image: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=800&q=80'
  }
];
