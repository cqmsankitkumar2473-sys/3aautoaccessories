import { Review } from '../types';

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    author: 'Vikramaditya Sharma',
    rating: 5,
    date: '3 days ago',
    comment: 'Excellent quality and fast installation. Highly recommended! Got the AlphaBeam 180W Bi-LED and Symphony ambient lights fitted on my Mahindra Thar. The night visibility is insane and Ankit Kumar personally supervised the zero-wire-cut installation.',
    carModel: 'Mahindra Thar 4x4',
    productPurchased: 'AlphaBeam Matrix 180W Bi-LED + Symphony Ambient Light',
    verified: true,
    location: 'Jaipur, Rajasthan',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
  },
  {
    id: 'rev-2',
    author: 'Rajesh Singhania',
    rating: 5,
    date: '1 week ago',
    comment: 'Best place for premium car accessories. Ankit bhai gave genuine suggestions rather than trying to upsell unnecessary stuff. The 10.1" 2K Android screen with wireless Apple CarPlay is super snappy with zero lag.',
    carModel: 'Hyundai Creta SX(O)',
    productPurchased: 'AuraPro 10.1" 2K Android CarPlay Screen + 7D Mats',
    verified: true,
    location: 'Delhi NCR',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80'
  },
  {
    id: 'rev-3',
    author: 'Mohit Chauhan',
    rating: 5,
    date: '2 weeks ago',
    comment: 'The 24K gold plated Hanuman Ji dashboard flag and brass stand is magnificent! Very heavy, premium finish and didn\'t move an inch even on bumpy off-road trails. 10/10 quality.',
    carModel: 'Scorpio-N Z8L',
    productPurchased: 'Royal 24K Gold Plated Brass Hanuman Ji Flag',
    verified: true,
    location: 'Chandigarh',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80'
  },
  {
    id: 'rev-4',
    author: 'Pooja Deshmukh',
    rating: 5,
    date: '3 weeks ago',
    comment: 'Installed the custom bucket fit Nappa seat covers and 3-color fog lamps. The fit & finish is just like factory OEM. The WhatsApp consultation with Ankit Kumar was very smooth.',
    carModel: 'Kia Seltos Facelift',
    productPurchased: 'Royal Nappa Seat Covers + ThunderLite Fog Projectors',
    verified: true,
    location: 'Mumbai',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80'
  },
  {
    id: 'rev-5',
    author: 'Amanpreet Singh',
    rating: 5,
    date: '1 month ago',
    comment: 'Got the Valvetronic exhaust fitted on my car. The exhaust note is sweet and loud at high revs, and completely silent for colony driving. Top notch craftsmanship from 3A Auto Accessories!',
    carModel: 'Volkswagen Polo GT TSI',
    productPurchased: 'Valvetronic Dual Stainless Steel Exhaust System',
    verified: true,
    location: 'Ludhiana',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80'
  }
];
