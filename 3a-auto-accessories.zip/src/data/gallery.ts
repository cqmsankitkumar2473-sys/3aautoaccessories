export interface GalleryItem {
  id: string;
  title: string;
  category: 'lighting' | 'interior' | 'exterior' | 'modification' | 'flags';
  carModel: string;
  beforeAfter?: boolean;
  image: string;
  description: string;
}

export const GALLERY_PROJECTS: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Mahindra Thar Matrix Bi-LED & Honeycomb Raptor Grille',
    category: 'lighting',
    carModel: 'Mahindra Thar 4x4',
    image: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=1000&q=80',
    description: 'Custom fitted with 180W Matrix Bi-LEDs and triple-amber marker grille with zero wire splicing.'
  },
  {
    id: 'gal-2',
    title: 'Hyundai Creta Symphony 64-Color Chasing Ambient Light & 2K QLED',
    category: 'interior',
    carModel: 'Hyundai Creta',
    image: 'https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=1000&q=80',
    description: 'Concealed 18-in-1 fiber optic acrylic ambient lights with full iOS/Android app integration.'
  },
  {
    id: 'gal-3',
    title: 'Toyota Fortuner VIP Nappa Leather Cabin & 7D Imperial Mats',
    category: 'interior',
    carModel: 'Toyota Fortuner Legender',
    image: 'https://images.unsplash.com/photo-1584345604476-8ec5e12e42dd?auto=format&fit=crop&w=1000&q=80',
    description: 'Dual-tone tan camel bespoke leatherette seat upholstery with custom memory foam cushions.'
  },
  {
    id: 'gal-4',
    title: 'Scorpio-N High-Lumen Bi-LED Fog Projectors with 3-Color Switch',
    category: 'lighting',
    carModel: 'Scorpio-N',
    image: 'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=1000&q=80',
    description: 'High-intensity dual beam fog lamps slicing through heavy highway mist and darkness.'
  },
  {
    id: 'gal-5',
    title: 'Valvetronic Dual Stainless Steel Exhaust on Custom Sedan',
    category: 'modification',
    carModel: 'Custom Sport Sedan',
    image: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=1000&q=80',
    description: 'Wireless key fob controlled dual-mode exhaust with deep bass rumble and burnt titanium tips.'
  },
  {
    id: 'gal-6',
    title: '24K Gold Sacred Hanuman Ji Flag & Dashboard Trims on Luxury SUV',
    category: 'flags',
    carModel: 'Tata Safari Dark Edition',
    image: 'https://images.unsplash.com/photo-1609358905581-e5088926b010?auto=format&fit=crop&w=1000&q=80',
    description: 'Auspicious handcrafted 24K gold plated brass temple flag base and pure silk embroidered dhwaj.'
  }
];
