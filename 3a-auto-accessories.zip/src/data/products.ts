import { Product } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  // 1. LED Headlights
  {
    id: 'prod-led-matrix-180w',
    name: 'AlphaBeam Matrix 180W Bi-LED Projector Lens Kit',
    category: 'led-headlights',
    categoryName: 'LED Headlights',
    price: 9499,
    originalPrice: 13999,
    rating: 4.9,
    reviewsCount: 142,
    image: 'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: true,
    badge: 'Best Seller',
    shortDesc: '180W 24,000LM German CSP LED Chips with Razor-sharp cut-off line and instant high-beam solenoid.',
    description: 'The AlphaBeam Matrix 180W kit transforms night driving into daylight clarity. Engineered with dual optical lens technology and high-speed silent turbo cooling fans (12,000 RPM). Delivers wide, uniform road illumination with zero glare to oncoming traffic.',
    specs: {
      'Power Output': '180W Pair (90W / Bulb)',
      'Brightness': '24,000 Lumens',
      'Color Temperature': '6000K Pure White Crystal Clear',
      'Lens Size': '3.0 Inch Blue Glass HD Convex Lens',
      'Cooling': 'Dual Copper Heat Pipes + Smart MagLev Fan',
      'Operating Voltage': '9V - 16V DC',
      'Waterproof Rating': 'IP68 Certified'
    },
    compatibleCars: ['Universal', 'Mahindra Thar', 'Scorpio-N', 'Hyundai Creta', 'Kia Seltos', 'Toyota Fortuner', 'Tata Harrier'],
    installationTime: '90 - 120 mins',
    warranty: '2 Years Replacement Warranty',
    isBestSeller: true
  },
  {
    id: 'prod-led-laser-bulbs',
    name: 'LaserBeam Ultra Turbo H4/H7 Direct Replacement Bulbs',
    category: 'led-headlights',
    categoryName: 'LED Headlights',
    price: 3499,
    originalPrice: 4999,
    rating: 4.8,
    reviewsCount: 89,
    image: 'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: false,
    badge: 'Plug & Play',
    shortDesc: '140W 18,000LM 1:1 OEM halogen socket fitment with no wire splicing required.',
    description: 'Direct 1:1 replacement LED bulbs that fit inside stock headlight dust caps without extra wiring or ballast boxes. Integrated CANBUS canceller prevents error codes on dashboard screens.',
    specs: {
      'Power': '140W / Pair',
      'Lumen': '18,000 LM',
      'Socket Options': 'H4, H7, H11, 9005, HB3',
      'Lifespan': '> 50,000 Hours',
      'Wiring': '100% Plug & Play (Zero wire cutting)'
    },
    compatibleCars: ['Universal', 'Maruti Swift', 'Brezza', 'Hyundai i20', 'Tata Punch', 'Honda City', 'Kia Sonet'],
    installationTime: '20 - 30 mins',
    warranty: '18 Months Warranty'
  },

  // 2. Fog Lamps
  {
    id: 'prod-fog-tri-color',
    name: 'ThunderLite 3.0" Tri-Color Waterproof Bi-LED Fog Projector',
    category: 'fog-lamps',
    categoryName: 'Fog Lamps',
    price: 5899,
    originalPrice: 8500,
    rating: 4.9,
    reviewsCount: 110,
    image: 'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: true,
    badge: 'All-Weather',
    shortDesc: 'Switch between 3000K Golden Yellow, 4300K Warm White & 6000K Pure White with dual high/low beam.',
    description: 'Equipped with an internal solenoid for instant high beam assist and multi-mode switchable color temperatures to slice through heavy fog, highway rainstorms, or city night driving.',
    specs: {
      'Color Modes': '3000K (Rain/Fog) / 4300K (Highway) / 6000K (City)',
      'Waterproof': 'IP68 Submersible Die-Cast Aluminum Body',
      'Lens': 'Clear Optic Convex Glass',
      'Bracket': 'Universal & Car-Specific Bumper Mounts Included',
      'Power': '120W Pair'
    },
    compatibleCars: ['Universal', 'Mahindra Thar', 'Creta', 'Scorpio-N', 'Grand Vitara', 'Baleno', 'Nexon'],
    installationTime: '45 - 60 mins',
    warranty: '2 Years Replacement Warranty',
    isBestSeller: true
  },

  // 3. Temple Flags & Spiritual Accessories
  {
    id: 'prod-flag-hanuman-gold',
    name: 'Royal 24K Gold Plated Brass Hanuman Ji Car Dashboard Flag & Stand',
    category: 'temple-flags',
    categoryName: 'Temple Flags',
    price: 1299,
    originalPrice: 1999,
    rating: 5.0,
    reviewsCount: 230,
    image: 'https://images.unsplash.com/photo-1609358905581-e5088926b010?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1609358905581-e5088926b010?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: true,
    badge: 'Sacred Gold Edition',
    shortDesc: 'Heavyweight brass construction with 24K micro-gold plating, saffron silk flag & non-slip magnetic base.',
    description: 'Bring sacred divine aura and protection to your car dashboard. Handcrafted by master artisans with heavy pure brass base that withstands road vibrations and heat without tarnishing.',
    specs: {
      'Material': 'Pure Heavy Cast Brass + 24K Gold Electroplating',
      'Flag Fabric': 'Weatherproof Double-Sided Embroidered Saffron Silk',
      'Mounting': 'Vibration-Absorbing 3M VHB Automotive Base',
      'Height': '5.5 Inches (Optimum Driver Line-of-Sight)',
      'Rust Proof': '100% Anti-Tarnish Coating'
    },
    compatibleCars: ['Universal fit for all Car Dashboards & Desks'],
    installationTime: 'Instant (Self-Adhesive)',
    warranty: 'Lifetime Tarnish-Free Guarantee',
    isBestSeller: true
  },
  {
    id: 'prod-flag-mahakal-trishul',
    name: 'Mahakal Sacred Trishul & Damru Dashboard Emblem with Flag',
    category: 'temple-flags',
    categoryName: 'Temple Flags',
    price: 999,
    originalPrice: 1499,
    rating: 4.9,
    reviewsCount: 164,
    image: 'https://images.unsplash.com/photo-1582738411706-bfc8e691d1c2?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1582738411706-bfc8e691d1c2?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: false,
    badge: 'Trending',
    shortDesc: 'Antique matte brass finish Shiv Trishul with velvet embroidered saffron flag for blessed road journeys.',
    description: 'A symbol of fearlessness and auspicious travel. Solid metal casting with antique detailing, balanced weight, and pre-fitted dashboard tape.',
    specs: {
      'Finish': 'Antique Gold / Matte Metallic',
      'Weight': '280 grams (Heavy Solid Feel)',
      'Dimensions': '14cm Height x 8cm Base',
      'Attachment': 'Heat-Resistant 3M Tape'
    },
    compatibleCars: ['Universal'],
    installationTime: 'Instant',
    warranty: '1 Year Warranty'
  },

  // 4. Car Interior Accessories
  {
    id: 'prod-ambient-symphony-64',
    name: 'Symphony 64-Color Smart App & Voice Active Ambient Lighting Kit',
    category: 'interior-accessories',
    categoryName: 'Interior Accessories',
    price: 6499,
    originalPrice: 9999,
    rating: 4.9,
    reviewsCount: 198,
    image: 'https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: true,
    badge: 'Luxury VIP Style',
    shortDesc: '18-in-1 Acrylic optical concealed light strip with chasing streamer modes, music sync & iOS/Android app.',
    description: 'Transform your cabin into a Maybach/Rolls-Royce ambiance. Ultra-thin 1mm acrylic light pipes hide seamlessly inside dashboard and door crevices with vibrant uniform glow and 210 dynamic chasing animations.',
    specs: {
      'Light Zones': '4 Doors + Dashboard + Footwells + Center Console + Door Handle Pockets',
      'Control': 'Bluetooth App + Wireless Physical Remote + OEM Button Sync',
      'Color Palette': '64 Million Spectrum + Dynamic Chasing RGB Streamers',
      'Sound Sync': 'High-Sensitivity Built-in Microphone for Music Beat Pulse',
      'Voltage': '12V Fuse Tap (Zero Wire Cut)'
    },
    compatibleCars: ['Universal', 'Mahindra Thar', 'Creta', 'Scorpio', 'Fortuner', 'Harrier', 'Swift', 'City'],
    installationTime: '120 - 150 mins',
    warranty: '2 Years Warranty',
    isBestSeller: true
  },
  {
    id: 'prod-screen-android-2k',
    name: 'AuraPro 10.1" 2K Ultra-HD Android Screen & Wireless CarPlay Head Unit',
    category: 'interior-accessories',
    categoryName: 'Interior Accessories',
    price: 16999,
    originalPrice: 24999,
    rating: 4.9,
    reviewsCount: 154,
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: true,
    badge: 'Flagship Tech',
    shortDesc: 'Octa-Core 8GB RAM + 128GB ROM, 2K QLED screen with 48-Band DSP Sound Processor & 360 Camera Support.',
    description: 'Seamless wireless Apple CarPlay and Android Auto with blazing fast responsiveness. Supports Google Maps, YouTube 4K, split-screen multitasking, optical audio output, and steering mounted control retention.',
    specs: {
      'Processor': '8-Core 2.0GHz High Performance CPU',
      'Memory': '8GB RAM + 128GB High-Speed Storage',
      'Display': '10.1 Inch 2000x1200 Quantum IPS Touchscreen',
      'Sound': 'Built-in 48-Band Digital Signal Processor (DSP)',
      'Connectivity': 'Wireless CarPlay, Wireless Android Auto, 4G SIM Slot, Dual-band WiFi, Bluetooth 5.2',
      'Camera': 'AHD 1080P Night Vision Reverse Camera Included'
    },
    compatibleCars: ['Custom Frame Fit for all Indian & Global Car Models'],
    installationTime: '60 - 90 mins',
    warranty: '2 Years On-Site Warranty'
  },
  {
    id: 'prod-mats-7d-imperial',
    name: '7D Imperial Custom Laser-Cut Waterproof Car Floor Mats',
    category: 'interior-accessories',
    categoryName: 'Interior Accessories',
    price: 3899,
    originalPrice: 5999,
    rating: 4.8,
    reviewsCount: 215,
    image: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: false,
    badge: 'Custom Fit',
    shortDesc: 'Dual-layer detachable curly grass mat over heavy-duty diamond stitched leatherette with full side wall coverage.',
    description: 'Precision laser-mapped to the floor contours of your exact vehicle. Traps mud, sand, spills, and dirt while giving an opulent premium leather floor aesthetic.',
    specs: {
      'Material': '7-Layer Composite Leatherette + Detachable Anti-Skid Curly Grass',
      'Coverage': 'Complete Floor & Side-Wall Edge Hugging',
      'Waterproof': '100% Spill & Mud Proof (Easy Hose Wash)',
      'Safety': 'Anti-Slip Grip Backing + Heel Rest Plate on Driver Side'
    },
    compatibleCars: ['Thar, Scorpio-N, Creta, Fortuner, Swift, Baleno, Nexon, Harrier, XUV700, City, etc.'],
    installationTime: '15 mins',
    warranty: '3 Years Durability Warranty'
  },
  {
    id: 'prod-seat-covers-nappa',
    name: 'Royal Nappa Leatherette Ultra-Fit Diamond Stitch Seat Covers',
    category: 'interior-accessories',
    categoryName: 'Interior Accessories',
    price: 8499,
    originalPrice: 12999,
    rating: 4.9,
    reviewsCount: 178,
    image: 'https://images.unsplash.com/photo-1584345604476-8ec5e12e42dd?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1584345604476-8ec5e12e42dd?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: true,
    badge: 'Bucket Fit',
    shortDesc: 'OEM bucket fit with high-density memory foam padding, breathable perforation, and side airbag deployment seams.',
    description: 'Upgrade your car seats to luxury airliner comfort. Handcrafted with authentic automotive-grade Nappa touch leatherette that remains cool in summer and supple in winter.',
    specs: {
      'Fitment': 'Custom Molded OEM Bucket Fit for specific model',
      'Padding': '14mm Ultra-Dense Memory Cushioning',
      'Safety': 'Side Airbag Compatible Tested Stitching',
      'Color Choices': 'Tan Camel, Obsidian Black, Ivory Beige, Dual Tone Wine'
    },
    compatibleCars: ['Available for 120+ Car Models'],
    installationTime: '120 mins',
    warranty: '5 Years Foam & Stitching Guarantee'
  },
  {
    id: 'prod-steering-carbon',
    name: 'Carbon Grip Perforated Breathable Ergonomic Steering Wheel Cover',
    category: 'interior-accessories',
    categoryName: 'Interior Accessories',
    price: 899,
    originalPrice: 1499,
    rating: 4.8,
    reviewsCount: 132,
    image: 'https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: false,
    badge: 'Sport Grip',
    shortDesc: 'Hydro-dipped carbon fiber accents with microfiber sweat-proof perforated leather and anti-slip inner rubber.',
    description: 'Enhance your steering feel, palm comfort, and cockpit sporty aesthetics. Provides sure-handed control during long highway cruises or spirited canyon carving.',
    specs: {
      'Material': 'Perforated Microfiber Leather + Carbon Composite',
      'Diameter': '37-38cm Universal Steering Fit (D-Cut & Round)',
      'Grip': 'Honeycomb Anti-Slip Rubber Inner Core'
    },
    compatibleCars: ['Universal'],
    installationTime: '5 mins',
    warranty: '1 Year Warranty'
  },

  // 5. Exterior Accessories
  {
    id: 'prod-door-visors-chrome',
    name: 'Sleek Injection-Molded Door Visors with Mirror Chrome Bead Strip',
    category: 'exterior-accessories',
    categoryName: 'Exterior Accessories',
    price: 1699,
    originalPrice: 2499,
    rating: 4.7,
    reviewsCount: 95,
    image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: false,
    badge: 'OEM Quality',
    shortDesc: 'Unbreakable virgin polycarbonate wind deflectors with laser-straight chrome bead line and pre-mounted 3M tape.',
    description: 'Allows you to roll your windows down during rains without water entering the cabin. Reduces aerodynamic wind noise and gives a continuous premium side profile.',
    specs: {
      'Pieces': 'Set of 4 / 6 Door Visors',
      'Material': 'High-Impact UV-Stabilized Polycarbonate',
      'Chrome Finish': 'Electroplated Stainless Chrome Line',
      'Attachment': 'Genuine 3M Double-Sided Foam Tape'
    },
    compatibleCars: ['Custom Mold for all Cars (Thar, Scorpio, Creta, Fortuner, Swift, Brezza, etc.)'],
    installationTime: '15 mins',
    warranty: '1 Year Replacement'
  },
  {
    id: 'prod-chrome-combo-kit',
    name: 'Tri-Coat High Gloss Mirror Chrome Exterior Styling Package',
    category: 'exterior-accessories',
    categoryName: 'Exterior Accessories',
    price: 3499,
    originalPrice: 5299,
    rating: 4.8,
    reviewsCount: 88,
    image: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: true,
    badge: 'Combo Savings',
    shortDesc: 'Complete 10-piece chrome embellishment set: Door handle bowls, mirror covers, headlamp & tail-lamp garnishes.',
    description: 'Add an executive touch to your vehicle exterior with triple-nickel mirror chrome trims that will not fade, rust, or peel under harsh sunlight.',
    specs: {
      'Package Includes': '4 Door Handle Covers + 4 Handle Catch Bowls + 2 ORVM Mirror Garnishes',
      'Coating': 'Triple Chrome Electroplating on ABS virgin plastic',
      'Mounting': 'Non-invasive 3M Automotive Adhesive'
    },
    compatibleCars: ['Creta, Brezza, Swift, Scorpio-N, Baleno, Grand Vitara, Seltos'],
    installationTime: '20 mins',
    warranty: '2 Years Anti-Peel Warranty'
  },

  // 6. Modification Parts
  {
    id: 'prod-valvetronic-exhaust',
    name: 'Valvetronic Remote-Controlled Dual Stainless Steel Exhaust System',
    category: 'modification-parts',
    categoryName: 'Modification Parts',
    price: 18999,
    originalPrice: 27999,
    rating: 4.9,
    reviewsCount: 76,
    image: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: true,
    badge: 'Enthusiast Choice',
    shortDesc: 'Switch from civil quiet cruising to roaring sporty exhaust note with the click of a keychain key fob.',
    description: 'Constructed with surgical grade T304 stainless steel and high-torque electric butterfly bypass valves. Delivers an aggressive deep sporty rumble when open, and reverts to whisper-quiet stock sound in residential areas.',
    specs: {
      'Material': 'T304 Aircraft Grade Polished Stainless Steel',
      'Control': 'Dual RF Wireless Remotes + Mobile App',
      'Pipe Diameter': '2.5" / 3.0" Mandrel Bent Flow',
      'Tips': 'Burnt Titanium Blue or Carbon Fiber Twin Tips'
    },
    compatibleCars: ['Mahindra Thar, Scorpio, Polo, City, Civic, Creta Turbo, BMW, Audi'],
    installationTime: '120 mins',
    warranty: '3 Years Rust & Motor Warranty'
  },
  {
    id: 'prod-grille-honeycomb-thar',
    name: 'Aggressive Armor Honeycomb Front Grille with Integrated LED Markers',
    category: 'modification-parts',
    categoryName: 'Modification Parts',
    price: 4899,
    originalPrice: 7499,
    rating: 5.0,
    reviewsCount: 118,
    image: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: false,
    badge: 'Aggressive Stance',
    shortDesc: 'Heavy-duty matte black ABS mesh front grille featuring 3 amber Raptor LED marker lights for dominant road presence.',
    description: 'Transform the face of your SUV with high-flow aerodynamic honeycomb structure that improves engine radiator cooling while delivering commanding road intimidation.',
    specs: {
      'Material': 'Impact-Resistant Virgin Automotive Grade ABS Plastic',
      'Markers': '3x Amber Waterproof Raptor LED DRLs',
      'Finish': 'Matte Armor Black (Paintable)',
      'Fitment': 'Direct Bolt-On to factory chassis mount points'
    },
    compatibleCars: ['Mahindra Thar 4x4 / RWD, Scorpio Classic, Scorpio-N'],
    installationTime: '30 mins',
    warranty: '2 Years Warranty'
  },

  // 7. Car Care & Detailing Products
  {
    id: 'prod-ceramic-coating-9h',
    name: '3A Pro-Shield 9H Hydrophobic Nano Ceramic Coating 50ml Master Kit',
    category: 'car-care',
    categoryName: 'Car Care Products',
    price: 2499,
    originalPrice: 3999,
    rating: 4.9,
    reviewsCount: 187,
    image: 'https://images.unsplash.com/photo-1607860108855-64acf2078ed9?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1607860108855-64acf2078ed9?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: true,
    badge: 'Pro Grade',
    shortDesc: 'Permanent 9H hardness glass shield with extreme hydrophobic water beading, scratch resistance & deep wet-gloss mirror shine.',
    description: 'Protects car paintwork against bird droppings, acid rain, UV oxidation, tree sap, and light swirl scratches. Kit includes 50ml 9H ceramic liquid, applicator sponge blocks, suede wipes, and microfiber buffing cloth.',
    specs: {
      'Hardness': '9H Diamond-Level Ceramic SIO2 Matrix',
      'Durability': 'Up to 3 Years Protective Layer',
      'Contact Angle': '115° Extreme Hydrophobic Self-Cleaning',
      'Coverage': '1 Bottle easily covers 1 Large SUV / 2 Compact Sedans'
    },
    compatibleCars: ['Universal for all painted automotive bodies & glass'],
    installationTime: 'DIY 45 mins / In-Store Application Available',
    warranty: 'Authentic German SIO2 Formula',
    isBestSeller: true
  },
  {
    id: 'prod-perfume-solar-spinner',
    name: 'Luxury Solar 360° Double-Ring Levitating Alloy Dashboard Car Cologne',
    category: 'car-care',
    categoryName: 'Car Care Products',
    price: 799,
    originalPrice: 1299,
    rating: 4.8,
    reviewsCount: 145,
    image: 'https://images.unsplash.com/photo-1615397349754-cfa2066a298e?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1615397349754-cfa2066a298e?auto=format&fit=crop&w=1200&q=80'
    ],
    inStock: true,
    featured: false,
    badge: 'Solar Magic',
    shortDesc: 'Solar-powered silent magnetic levitation dual-ring spinner diffusing organic French essential oils with zero battery.',
    description: 'Spins automatically under sunlight to disperse crisp Cologne/Ocean breeze fragrance throughout the entire cabin. Made from solid alloy with wooden aroma ring.',
    specs: {
      'Power': '100% Sunlight Solar Kinetic Driven (No charging or wires)',
      'Fragrance': 'French Ocean Breeze + Cologne Ring Included',
      'Material': 'Aviation Grade Aluminum Alloy'
    },
    compatibleCars: ['Universal Dashboard Fit'],
    installationTime: 'Instant (Reusable Washable Gel Pad)',
    warranty: '6 Months Replacement'
  }
];
